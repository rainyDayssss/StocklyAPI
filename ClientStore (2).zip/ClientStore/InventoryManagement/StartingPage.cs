﻿using Infrastructure.Utilities;
using InventoryManagement;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Infrastructure.Services;
using GroceryCalcApp.Services;

namespace ClientStore
{
    public partial class StartingPage : Form
    {
        private readonly AppServices _appServices;
        public StartingPage(AppServices appServices)
        {
            InitializeComponent();
            _appServices = appServices;
        }

        private void adminButton_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            HomePage homePage = new HomePage(_appServices) { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.Controls.Add(homePage);
            homePage.Show();
        }

        private void clientButton_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            StartPage startPage = new StartPage(_appServices, new PurchaseSession(new DiscountCalculatorService())) { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.Controls.Add(startPage);
            startPage.Show();
        }
    }
}
