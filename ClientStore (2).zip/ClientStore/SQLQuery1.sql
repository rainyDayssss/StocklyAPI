﻿select * from SalesDetails

select * from Inventory