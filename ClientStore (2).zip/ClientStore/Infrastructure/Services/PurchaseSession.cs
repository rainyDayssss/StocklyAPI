﻿using Core.DTOs;
using Core.Model;
using GroceryCalcApp.Models;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace GroceryCalcApp.Services
{
    public class PurchaseSession
    {
        private readonly List<InventoryDTO> _cart;
        private readonly DiscountCalculatorService _discountService;
        public decimal Subtotal { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal TotalFinal { get; set; }
        public DateTime SaleDate { get; set; }
        public PurchaseSession(DiscountCalculatorService discountService)
        {
            _cart = new List<InventoryDTO>();
            _discountService = discountService;
        }

        public void AddItem(InventoryDTO item, int quantity)
        {
            foreach (InventoryDTO i in _cart) {
                if (i.Id == item.Id) {
                    i.PurchaseQuantity += quantity;
                    return;
                }
            }
            item.PurchaseQuantity = quantity;
            _cart.Add(item);
        }

        public void DeleteItemById(int id)
        {
            var item = _cart.FirstOrDefault(i => i.Id == id);
            if (item != null)
            {
                _cart.Remove(item);
            }
        }

        public decimal GetSubtotal()
        {
            Subtotal = 0m;
            foreach (InventoryDTO inv in _cart) { 
                Subtotal += inv.Price * inv.PurchaseQuantity;
            }
            return Subtotal;
        }

        public decimal GetDiscount()
        {
            return _discountService.CalculateDiscount(GetSubtotal());
        }

        public decimal GetDiscountAmount()
        {
            DiscountAmount = GetDiscount();
            return DiscountAmount; // Alias method for clarity in UI or logic
        }

        public decimal GetFinalTotal()
        {

            TotalFinal = GetSubtotal() - GetDiscount();
            return TotalFinal;
        }

        public List<InventoryDTO> GetAllItems()
        {
            return _cart;
        }

        public void RestartSession()
        {
            _cart.Clear();
        }
    }
}
