﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroceryCalcApp.Models
{
    public static class Discount
    {
        public const Decimal TEN_PERCENT = 0.10m;
        public const Decimal FIFTEEN_PERCENT = 0.15m;
        public const Decimal TWENTY_PERCENT = 0.20m;
    }
}
