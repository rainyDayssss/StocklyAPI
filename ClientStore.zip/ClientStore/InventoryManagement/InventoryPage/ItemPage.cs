﻿using CuoreUI.Components;
using System;
using System.Windows.Forms;
using CuoreUI;
using Infrastructure.Utilities;
using System.Windows.Forms.VisualStyles;
using Core.Model;


namespace InventoryManagement
{
    public partial class ItemPage : Form
    {
        private readonly AppServices _appServices;
        public ItemPage(AppServices appServices)
        {
            InitializeComponent();
            _appServices = appServices;
            // Example: Add rows to DataGridView
            /// view ite,

            refreshItems();
        }


        private void cuiLabel1_Load(object sender, EventArgs e)
        {

        }

        // add btn 
        private void AddButton_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            DeleteButton.Enabled = false;
            grid.Enabled = false;


        }

        // add item btn
        private void addItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            DeleteButton.Enabled = true;
            grid.Enabled = true;
            // add product name
            _appServices.ItemService.Add(new Core.Model.Item
            {
                Name = cuiTextBox1.Content,
                Price = Decimal.Parse(cuiTextBox2.Content),
            });

            refreshItems();

            // clear texts
            cuiTextBox1.Content = "";
            cuiTextBox2.Content = "";
        }

        // Get all items from db
        private void refreshItems()
        {
            grid.Rows.Clear();
            foreach (Item item in _appServices.ItemService.GetAll())
            {
                grid.Rows.Add(item.Id, item.Name, "$" + item.Price);
            }
        }

        private void deletePanel_Paint(object sender, PaintEventArgs e)
        {

            deletePanel.Location = new Point(309, 231);
        }

        // cancel btn for add item panel
        private void cancel_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            DeleteButton.Enabled = true;
            grid.Enabled = true;

            // clear texts
            cuiTextBox1.Content = "";
            cuiTextBox2.Content = "";
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            deletePanel.Visible = true;
            AddButton.Enabled = false;
            grid.Enabled = false;


        }

        private void cuiLabel4_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Make sure the click is on a valid row and a button column
            if (e.RowIndex >= 0 && grid.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                // Step 1: Get the ID from the clicked row
                int id = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Column1"].Value);

                // Step 2: Delete from the database
                bool success = _appServices.ItemService.DeleteById(id);

                // Step 3: Remove from grid if successful
                if (success)
                {
                    grid.Rows.RemoveAt(e.RowIndex);
                }
                else
                {
                    MessageBox.Show("Failed to delete from database.");
                }
            }
        }

        // delete item
        private void deleteItem_Click(object sender, EventArgs e)
        {
            deletePanel.Visible = false;
            AddButton.Enabled = true;
            grid.Enabled = true;

            // add error handling here for invalid input

            _appServices.ItemService.DeleteById(int.Parse(cuiTextBox4.Content));
            refreshItems();
            cuiTextBox4.Content = "";
        }

        // cancel btn for delete panel
        private void cuiButton1_Click(object sender, EventArgs e)
        {
            deletePanel.Visible = false;
            AddButton.Enabled = true;
            grid.Enabled = true;
            cuiTextBox4.Content = "";
        }
    }
}
