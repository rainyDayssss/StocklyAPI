﻿using CuoreUI.Components;
using System;
using System.Drawing;
using System.Windows.Forms;
using CuoreUI;
using Infrastructure.Utilities;
using Core.Model;

namespace InventoryManagement
{
    public partial class ItemPage : Form
    {
        private readonly AppServices _appServices;
        private bool isEditMode = false;
        private int editingItemId = -1;

        public ItemPage(AppServices appServices)
        {
            InitializeComponent();
            _appServices = appServices;
            SetupGridButtons();
            refreshItems();
        }

        private void SetupGridButtons()
        {
            grid.Columns.Clear();

            grid.Columns.Add("Column1", "ID");
            grid.Columns["Column1"].ReadOnly = true;
            grid.Columns.Add("Column2", "Name");
            grid.Columns.Add("Column3", "Price");

            var editButton = new DataGridViewButtonColumn
            {
                Name = "Edit",
                HeaderText = "",
                Text = "Edit",
                UseColumnTextForButtonValue = true,
                FlatStyle = FlatStyle.Popup
            };
            grid.Columns.Add(editButton);

            var deleteButton = new DataGridViewButtonColumn
            {
                Name = "Delete",
                HeaderText = "",
                Text = "Delete",
                UseColumnTextForButtonValue = true,
                FlatStyle = FlatStyle.Popup
            };
            grid.Columns.Add(deleteButton);
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            editPanel.Visible = false;
            deletePanel.Visible = false;

            DeleteButton.Enabled = false;
            AddButton.Enabled = false;
            grid.Enabled = false;

            isEditMode = false;
            editingItemId = -1;

            cuiTextBox1.Content = "";
            cuiTextBox2.Content = "";
            addItem.Text = "Add";
        }

        private void addItem_Click(object sender, EventArgs e)
        {
            string nameInput = cuiTextBox1.Content.Trim();
            string priceInput = cuiTextBox2.Content.Trim();

            if (string.IsNullOrWhiteSpace(nameInput))
            {
                MessageBox.Show("Item name cannot be empty.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!decimal.TryParse(priceInput, out decimal price) || price < 0)
            {
                MessageBox.Show("Invalid price. Please enter a valid positive number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _appServices.ItemService.Add(new Item
            {
                Name = nameInput,
                Price = price
            });

            refreshItems();
            cuiTextBox1.Content = "";
            cuiTextBox2.Content = "";
            panel1.Visible = false;
            DeleteButton.Enabled = true;
            AddButton.Enabled = true;
            grid.Enabled = true;
        }

        private void refreshItems()
        {
            grid.Rows.Clear();
            foreach (Item item in _appServices.ItemService.GetAll())
            {
                grid.Rows.Add(item.Id, item.Name, "$" + item.Price);
            }
        }

        private void grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && grid.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                string columnName = grid.Columns[e.ColumnIndex].Name;
                int itemId = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Column1"].Value);

                if (columnName == "Edit")
                {
                    isEditMode = true;
                    editingItemId = itemId;

                    itemName.Content = grid.Rows[e.RowIndex].Cells["Column2"].Value.ToString();
                    Price.Content = grid.Rows[e.RowIndex].Cells["Column3"].Value.ToString().Replace("$", "");

                    panel1.Visible = false;
                    deletePanel.Visible = false;
                    editPanel.Visible = true;

                    DeleteButton.Enabled = false;
                    AddButton.Enabled = false;
                    grid.Enabled = false;
                }
                else if (columnName == "Delete")
                {
                    bool success = _appServices.ItemService.DeleteById(itemId);
                    if (success)
                        grid.Rows.RemoveAt(e.RowIndex);
                    else
                        MessageBox.Show("Failed to delete item with ID " + itemId);
                }
            }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            DeleteButton.Enabled = true;
            AddButton.Enabled = true;
            grid.Enabled = true;

            cuiTextBox1.Content = "";
            cuiTextBox2.Content = "";
            isEditMode = false;
            editingItemId = -1;
            addItem.Text = "Add";
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            deletePanel.Visible = true;
            panel1.Visible = false;
            editPanel.Visible = false;

            AddButton.Enabled = false;
            grid.Enabled = false;
        }

        private void deleteItem_Click(object sender, EventArgs e)
        {
            deletePanel.Visible = false;
            AddButton.Enabled = true;
            grid.Enabled = true;

            string input = cuiTextBox4.Content.Trim();
            if (!int.TryParse(input, out int itemId))
            {
                MessageBox.Show("Invalid ID input. Please enter a valid numeric Id.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cuiTextBox4.Content = "";
                return;
            }

            bool deleted = _appServices.ItemService.DeleteById(itemId);
            if (!deleted)
            {
                MessageBox.Show($"No item found with Id {itemId}.", "Deletion Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            refreshItems();
            cuiTextBox4.Content = "";
        }

        private void cuiButton1_Click(object sender, EventArgs e)
        {
            deletePanel.Visible = false;
            AddButton.Enabled = true;
            grid.Enabled = true;
            cuiTextBox4.Content = "";
        }

        private void updateItem_Click(object sender, EventArgs e)
        {

        }

        private void cancelEdit_Click(object sender, EventArgs e)
        {

        }

        private void cuiLabel1_Load(object sender, EventArgs e) { }
        private void cuiLabel2_Load(object sender, EventArgs e) { }
        private void cuiLabel4_Load(object sender, EventArgs e) { }
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void deletePanel_Paint(object sender, PaintEventArgs e) { deletePanel.Location = new Point(309, 231); }

        // update btn
        private void editBtn_Click(object sender, EventArgs e)
        {
            string nameInput = itemName.Content.Trim();
            string priceInput = Price.Content.Trim();

            if (string.IsNullOrWhiteSpace(nameInput))
            {
                MessageBox.Show("Item name cannot be empty.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!decimal.TryParse(priceInput, out decimal price) || price < 0)
            {
                MessageBox.Show("Invalid price. Please enter a valid positive number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var updated = _appServices.ItemService.Update(new Item
            {
                Id = editingItemId,
                Name = nameInput,
                Price = price
            });

            if (!updated)
            {
                MessageBox.Show("Failed to update item.");
            }

            isEditMode = false;
            editingItemId = -1;

            refreshItems();

            editPanel.Visible = false;
            DeleteButton.Enabled = true;
            AddButton.Enabled = true;
            grid.Enabled = true;

            itemName.Content = "";
            Price.Content = "";

        }

        // cancel edit btn
        private void cancelEdit_Click_1(object sender, EventArgs e)
        {
            isEditMode = false;
            editingItemId = -1;

            editPanel.Visible = false;
            DeleteButton.Enabled = true;
            AddButton.Enabled = true;
            grid.Enabled = true;

            itemName.Content = "";
            Price.Content = "";
        }

        private void cancelEdit_Click_2(object sender, EventArgs e)
        {
            isEditMode = false;
            editingItemId = -1;

            editPanel.Visible = false;
            DeleteButton.Enabled = true;
            AddButton.Enabled = true;
            grid.Enabled = true;

            itemName.Content = "";
            Price.Content = "";
        }
    }
}
