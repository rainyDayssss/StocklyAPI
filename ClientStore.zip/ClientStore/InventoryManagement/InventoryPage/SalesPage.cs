﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Core.DTOs;
using Infrastructure.Utilities;

namespace InventoryManagement
{
    public partial class SalesPage : Form
    {
        private readonly AppServices _appServices;
        public SalesPage(AppServices appServices)
        {
            InitializeComponent();
            _appServices = appServices;

            // show all the SalesDetailsDTO from db
            //refreshSalesDetails();

            refreshSalesDetails();
        }

        // get all salesDetailsDTO from db
        private void refreshSalesDetails() {
            foreach (SalesDetailsDTO inv in _appServices.SalesDetailsService.GetAll())
            {
                // Sale Date, Sale Id, Item Id, QuanitySold, SubTotal, Total Amount
                grid.Rows.Add(inv.SaleDate.ToString("dd-MM-yyyy"), inv.SaleId, inv.ItemId, inv.QuantitySold, "$" + inv.SubTotal, "$" + inv.TotalAmount);
            }
        }

        private void grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
