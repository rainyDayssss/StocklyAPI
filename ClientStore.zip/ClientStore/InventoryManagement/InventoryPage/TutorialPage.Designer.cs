﻿namespace InventoryManagement
{
    partial class TutorialPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TutorialPage));
            cuiLabel4 = new CuoreUI.Controls.cuiLabel();
            cuiLabel3 = new CuoreUI.Controls.cuiLabel();
            cuiLabel1 = new CuoreUI.Controls.cuiLabel();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            cuiPanel1 = new CuoreUI.Controls.cuiPanel();
            cuiPanel3 = new CuoreUI.Controls.cuiPanel();
            cuiLabel7 = new CuoreUI.Controls.cuiLabel();
            cuiPanel4 = new CuoreUI.Controls.cuiPanel();
            cuiLabel8 = new CuoreUI.Controls.cuiLabel();
            cuiLabel2 = new CuoreUI.Controls.cuiLabel();
            cuiPanel2 = new CuoreUI.Controls.cuiPanel();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label4 = new Label();
            label5 = new Label();
            label13 = new Label();
            label14 = new Label();
            label9 = new Label();
            label10 = new Label();
            cuiPanel1.SuspendLayout();
            cuiPanel3.SuspendLayout();
            cuiPanel4.SuspendLayout();
            cuiPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // cuiLabel4
            // 
            cuiLabel4.AutoValidate = AutoValidate.EnablePreventFocusChange;
            cuiLabel4.BackgroundImageLayout = ImageLayout.None;
            cuiLabel4.Content = "Smart,\\ simple\\ inventory\\ and\\ sales\\ management\\.\\ Track\\ stock,\\ manage\\ items,\\ and\\ get\\ instant\\ reports\\ —\\ all\\ in\\ one\\ place\\.";
            cuiLabel4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cuiLabel4.ForeColor = Color.White;
            cuiLabel4.HorizontalAlignment = StringAlignment.Center;
            cuiLabel4.Location = new Point(122, 96);
            cuiLabel4.Margin = new Padding(4, 3, 4, 3);
            cuiLabel4.Name = "cuiLabel4";
            cuiLabel4.Size = new Size(876, 19);
            cuiLabel4.TabIndex = 11;
            cuiLabel4.VerticalAlignment = StringAlignment.Center;
            // 
            // cuiLabel3
            // 
            cuiLabel3.AutoValidate = AutoValidate.EnablePreventFocusChange;
            cuiLabel3.BackgroundImage = (Image)resources.GetObject("cuiLabel3.BackgroundImage");
            cuiLabel3.BackgroundImageLayout = ImageLayout.None;
            cuiLabel3.Content = "Welcome\\ to\\ Stockly\\ ";
            cuiLabel3.Font = new Font("Arial", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cuiLabel3.ForeColor = Color.White;
            cuiLabel3.HorizontalAlignment = StringAlignment.Center;
            cuiLabel3.Location = new Point(32, 17);
            cuiLabel3.Margin = new Padding(4, 3, 4, 3);
            cuiLabel3.Name = "cuiLabel3";
            cuiLabel3.Size = new Size(543, 98);
            cuiLabel3.TabIndex = 12;
            cuiLabel3.VerticalAlignment = StringAlignment.Center;
            // 
            // cuiLabel1
            // 
            cuiLabel1.AutoValidate = AutoValidate.EnablePreventFocusChange;
            cuiLabel1.BackgroundImageLayout = ImageLayout.None;
            cuiLabel1.Content = "Item\\ Page";
            cuiLabel1.Font = new Font("Arial", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cuiLabel1.ForeColor = Color.White;
            cuiLabel1.HorizontalAlignment = StringAlignment.Center;
            cuiLabel1.Location = new Point(38, 18);
            cuiLabel1.Margin = new Padding(4, 3, 4, 3);
            cuiLabel1.Name = "cuiLabel1";
            cuiLabel1.Size = new Size(169, 43);
            cuiLabel1.TabIndex = 15;
            cuiLabel1.VerticalAlignment = StringAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F);
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(80, 65);
            label1.Name = "label1";
            label1.Size = new Size(134, 24);
            label1.TabIndex = 16;
            label1.Text = "Can Add Item";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 15.75F);
            label2.ForeColor = Color.Transparent;
            label2.Location = new Point(81, 95);
            label2.Name = "label2";
            label2.Size = new Size(166, 24);
            label2.TabIndex = 16;
            label2.Text = "Can Update Item";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 15.75F);
            label3.ForeColor = Color.Transparent;
            label3.Location = new Point(81, 124);
            label3.Name = "label3";
            label3.Size = new Size(182, 24);
            label3.TabIndex = 16;
            label3.Text = "Can View All Items";
            // 
            // cuiPanel1
            // 
            cuiPanel1.BackColor = Color.Transparent;
            cuiPanel1.Controls.Add(label2);
            cuiPanel1.Controls.Add(label4);
            cuiPanel1.Controls.Add(cuiLabel1);
            cuiPanel1.Controls.Add(label3);
            cuiPanel1.Controls.Add(label1);
            cuiPanel1.Location = new Point(51, 145);
            cuiPanel1.Name = "cuiPanel1";
            cuiPanel1.OutlineThickness = 1F;
            cuiPanel1.PanelColor = Color.FromArgb(75, 91, 137);
            cuiPanel1.PanelOutlineColor = Color.FromArgb(75, 91, 137);
            cuiPanel1.Rounding = new Padding(8);
            cuiPanel1.Size = new Size(321, 201);
            cuiPanel1.TabIndex = 17;
            // 
            // cuiPanel3
            // 
            cuiPanel3.BackColor = Color.Transparent;
            cuiPanel3.Controls.Add(label10);
            cuiPanel3.Controls.Add(label9);
            cuiPanel3.Controls.Add(label14);
            cuiPanel3.Controls.Add(cuiLabel7);
            cuiPanel3.Location = new Point(540, 370);
            cuiPanel3.Name = "cuiPanel3";
            cuiPanel3.OutlineThickness = 1F;
            cuiPanel3.PanelColor = Color.FromArgb(75, 91, 137);
            cuiPanel3.PanelOutlineColor = Color.FromArgb(75, 91, 137);
            cuiPanel3.Rounding = new Padding(8);
            cuiPanel3.Size = new Size(458, 208);
            cuiPanel3.TabIndex = 17;
            // 
            // cuiLabel7
            // 
            cuiLabel7.AutoValidate = AutoValidate.EnablePreventFocusChange;
            cuiLabel7.BackgroundImageLayout = ImageLayout.None;
            cuiLabel7.Content = "Reports\\ Page";
            cuiLabel7.Font = new Font("Arial", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cuiLabel7.ForeColor = Color.White;
            cuiLabel7.HorizontalAlignment = StringAlignment.Center;
            cuiLabel7.Location = new Point(108, 18);
            cuiLabel7.Margin = new Padding(4, 3, 4, 3);
            cuiLabel7.Name = "cuiLabel7";
            cuiLabel7.Size = new Size(227, 43);
            cuiLabel7.TabIndex = 15;
            cuiLabel7.VerticalAlignment = StringAlignment.Center;
            // 
            // cuiPanel4
            // 
            cuiPanel4.BackColor = Color.Transparent;
            cuiPanel4.Controls.Add(label13);
            cuiPanel4.Controls.Add(cuiLabel8);
            cuiPanel4.Location = new Point(397, 145);
            cuiPanel4.Name = "cuiPanel4";
            cuiPanel4.OutlineThickness = 1F;
            cuiPanel4.PanelColor = Color.FromArgb(75, 91, 137);
            cuiPanel4.PanelOutlineColor = Color.FromArgb(75, 91, 137);
            cuiPanel4.Rounding = new Padding(8);
            cuiPanel4.Size = new Size(601, 201);
            cuiPanel4.TabIndex = 17;
            // 
            // cuiLabel8
            // 
            cuiLabel8.AutoValidate = AutoValidate.EnablePreventFocusChange;
            cuiLabel8.BackgroundImageLayout = ImageLayout.None;
            cuiLabel8.Content = "Sales\\ Page";
            cuiLabel8.Font = new Font("Arial", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cuiLabel8.ForeColor = Color.White;
            cuiLabel8.HorizontalAlignment = StringAlignment.Center;
            cuiLabel8.Location = new Point(200, 65);
            cuiLabel8.Margin = new Padding(4, 3, 4, 3);
            cuiLabel8.Name = "cuiLabel8";
            cuiLabel8.Size = new Size(227, 43);
            cuiLabel8.TabIndex = 15;
            cuiLabel8.VerticalAlignment = StringAlignment.Center;
            // 
            // cuiLabel2
            // 
            cuiLabel2.AutoValidate = AutoValidate.EnablePreventFocusChange;
            cuiLabel2.BackgroundImageLayout = ImageLayout.None;
            cuiLabel2.Content = "Inventory\\ Page";
            cuiLabel2.Font = new Font("Arial", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cuiLabel2.ForeColor = Color.White;
            cuiLabel2.HorizontalAlignment = StringAlignment.Center;
            cuiLabel2.Location = new Point(99, 18);
            cuiLabel2.Margin = new Padding(4, 3, 4, 3);
            cuiLabel2.Name = "cuiLabel2";
            cuiLabel2.Size = new Size(250, 43);
            cuiLabel2.TabIndex = 15;
            cuiLabel2.VerticalAlignment = StringAlignment.Center;
            // 
            // cuiPanel2
            // 
            cuiPanel2.BackColor = Color.Transparent;
            cuiPanel2.Controls.Add(label8);
            cuiPanel2.Controls.Add(label7);
            cuiPanel2.Controls.Add(label6);
            cuiPanel2.Controls.Add(label5);
            cuiPanel2.Controls.Add(cuiLabel2);
            cuiPanel2.Location = new Point(51, 370);
            cuiPanel2.Name = "cuiPanel2";
            cuiPanel2.OutlineThickness = 1F;
            cuiPanel2.PanelColor = Color.FromArgb(75, 91, 137);
            cuiPanel2.PanelOutlineColor = Color.FromArgb(75, 91, 137);
            cuiPanel2.Rounding = new Padding(8);
            cuiPanel2.Size = new Size(450, 208);
            cuiPanel2.TabIndex = 17;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 15.75F);
            label6.ForeColor = Color.Transparent;
            label6.Location = new Point(158, 93);
            label6.Name = "label6";
            label6.Size = new Size(240, 24);
            label6.TabIndex = 18;
            label6.Text = "Can Update Item's Stock";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 15.75F);
            label7.ForeColor = Color.Transparent;
            label7.Location = new Point(158, 122);
            label7.Name = "label7";
            label7.Size = new Size(182, 24);
            label7.TabIndex = 19;
            label7.Text = "Can View All Items";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 15.75F);
            label8.ForeColor = Color.Transparent;
            label8.Location = new Point(158, 146);
            label8.Name = "label8";
            label8.Size = new Size(161, 24);
            label8.TabIndex = 17;
            label8.Text = "Can Delete Item";
            label8.Click += label8_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 15.75F);
            label4.ForeColor = Color.Transparent;
            label4.Location = new Point(81, 152);
            label4.Name = "label4";
            label4.Size = new Size(161, 24);
            label4.TabIndex = 16;
            label4.Text = "Can Delete Item";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 15.75F);
            label5.ForeColor = Color.Transparent;
            label5.Location = new Point(158, 65);
            label5.Name = "label5";
            label5.Size = new Size(250, 24);
            label5.TabIndex = 17;
            label5.Text = "Can Add Stock To An Item";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 15.75F);
            label13.ForeColor = Color.Transparent;
            label13.Location = new Point(273, 124);
            label13.Name = "label13";
            label13.Size = new Size(184, 24);
            label13.TabIndex = 20;
            label13.Text = "Can View All Sales";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 15.75F);
            label14.ForeColor = Color.Transparent;
            label14.Location = new Point(178, 74);
            label14.Name = "label14";
            label14.Size = new Size(179, 24);
            label14.TabIndex = 21;
            label14.Text = "Can View Reports";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 15.75F);
            label9.ForeColor = Color.Transparent;
            label9.Location = new Point(178, 110);
            label9.Name = "label9";
            label9.Size = new Size(179, 24);
            label9.TabIndex = 22;
            label9.Text = "Can View Reports";
            label9.Click += label9_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 15.75F);
            label10.ForeColor = Color.Transparent;
            label10.Location = new Point(178, 134);
            label10.Name = "label10";
            label10.Size = new Size(154, 24);
            label10.TabIndex = 23;
            label10.Text = "Between Dates";
            // 
            // TutorialPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(111, 137, 217);
            ClientSize = new Size(1019, 679);
            Controls.Add(cuiPanel3);
            Controls.Add(cuiPanel2);
            Controls.Add(cuiPanel4);
            Controls.Add(cuiPanel1);
            Controls.Add(cuiLabel4);
            Controls.Add(cuiLabel3);
            FormBorderStyle = FormBorderStyle.None;
            Name = "TutorialPage";
            Text = "TutorialPage";
            cuiPanel1.ResumeLayout(false);
            cuiPanel1.PerformLayout();
            cuiPanel3.ResumeLayout(false);
            cuiPanel3.PerformLayout();
            cuiPanel4.ResumeLayout(false);
            cuiPanel4.PerformLayout();
            cuiPanel2.ResumeLayout(false);
            cuiPanel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private CuoreUI.Controls.cuiLabel cuiLabel4;
        private CuoreUI.Controls.cuiLabel cuiLabel3;
        private CuoreUI.Controls.cuiLabel cuiLabel1;
        private Label label1;
        private Label label2;
        private Label label3;
        private CuoreUI.Controls.cuiPanel cuiPanel1;
        private CuoreUI.Controls.cuiPanel cuiPanel3;
        private CuoreUI.Controls.cuiLabel cuiLabel7;
        private CuoreUI.Controls.cuiPanel cuiPanel4;
        private CuoreUI.Controls.cuiLabel cuiLabel2;
        private CuoreUI.Controls.cuiPanel cuiPanel2;
        private CuoreUI.Controls.cuiLabel cuiLabel8;
        private Label label4;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label9;
        private Label label14;
        private Label label13;
        private Label label5;
        private Label label10;
    }
}