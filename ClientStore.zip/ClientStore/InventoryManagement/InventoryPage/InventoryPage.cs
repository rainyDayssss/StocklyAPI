﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Core.DTOs;
using Infrastructure.Utilities;

namespace InventoryManagement
{
    public partial class InventoryPage : Form
    {
        private readonly AppServices _appServices;
        private bool isEditMode = false;
        private int editingItemId = -1;

        public InventoryPage(AppServices appServices)
        {
            InitializeComponent();
            _appServices = appServices;
            deletePanel1.Location = new Point(309, 231);
            SetupGridButtons();
            refreshItems();
        }

        private void SetupGridButtons()
        {
            grid.Columns.Clear();
            grid.Columns.Add("Column1", "Item ID");
            grid.Columns["Column1"].ReadOnly = true;
            grid.Columns.Add("Column2", "Item Name");
            grid.Columns["Column2"].ReadOnly = true;
            grid.Columns.Add("Column3", "Quantity");

            var editButton = new DataGridViewButtonColumn
            {
                Name = "Edit",
                HeaderText = "",
                Text = "Edit",
                UseColumnTextForButtonValue = true,
                FlatStyle = FlatStyle.Popup
            };
            grid.Columns.Add(editButton);

            var deleteButton = new DataGridViewButtonColumn
            {
                Name = "Delete",
                HeaderText = "",
                Text = "Delete",
                UseColumnTextForButtonValue = true,
                FlatStyle = FlatStyle.Popup
            };
            grid.Columns.Add(deleteButton);
        }

        private void refreshItems()
        {
            grid.Rows.Clear();
            foreach (InventoryDTO inv in _appServices.InventoryService.GetAll())
            {
                grid.Rows.Add(inv.ItemId, inv.ItemName, inv.Quantity);
            }
        }

        // add btn
        private void AddButton_Click(object sender, EventArgs e)
        {
            // Make the panel visible for adding a new item.
            panel1.Visible = true;

            // Disable the Delete button and the grid to prevent conflicting actions.
            DeleteButton.Enabled = false;
            grid.Enabled = false;

            // Clear previous inputs and enable the fields for the user to enter new values.
            cuiTextBox1.Content = "";
            quantityBox.Content = "";
            cuiTextBox1.Enabled = true;

            // Set the button text to "Add" since we are adding a new item.
            addItem.Text = "Add";
        }


        // add item
        private void addItem_Click(object sender, EventArgs e)
        {
            string itemIdInput = cuiTextBox1.Content.Trim();
            string quantityInput = cuiTextBox2.Content.Trim();

            if (!int.TryParse(itemIdInput, out int itemId) || itemId < 0)
            {
                MessageBox.Show("Invalid Item ID. Please enter a valid positive number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(quantityInput, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Invalid Quantity. Please enter a positive number greater than 0.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (isEditMode) // Update the existing item
            {
                _appServices.InventoryService.UpdateQuantityById(itemId, quantity);
                isEditMode = false; // Reset edit mode after update.
                editingItemId = -1; // Clear the editing state.
            }
            else // Add new item
            {
                bool exists = _appServices.ItemService.GetAll().Any(item => item.Id == itemId);
                if (!exists)
                {
                    MessageBox.Show("The Item ID does not exist in the Item table.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _appServices.InventoryService.AddQuantityByItemId(itemId, quantity); // Add the new item or update if it exists
            }

            // After adding or updating, reset the UI and refresh the grid.
            editPanel.Visible = false;
            panel1.Visible = false;
            DeleteButton.Enabled = true;
            grid.Enabled = true;
            refreshItems(); // Refresh the grid data
            cuiTextBox1.Content = "";
            cuiTextBox2.Content = "";
            quantityBox.Content = "";
            cuiTextBox1.Enabled = true;
            addItem.Text = "Add"; // Reset the button text
        }


        private void grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && grid.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                string columnName = grid.Columns[e.ColumnIndex].Name;
                int itemId = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Column1"].Value);

                if (columnName == "Edit")
                {
                    isEditMode = true;
                    editingItemId = itemId;

                    cuiTextBox1.Content = itemId.ToString();
                    quantityBox.Content = grid.Rows[e.RowIndex].Cells["Column3"].Value.ToString();
                    cuiTextBox1.Enabled = false;

                    editPanel.Visible = true;
                    DeleteButton.Enabled = false;
                    grid.Enabled = false;
                    addItem.Text = "Update";
                }
                else if (columnName == "Delete")
                {
                    bool success = _appServices.InventoryService.DeleteById(itemId);
                    if (success)
                        grid.Rows.RemoveAt(e.RowIndex);
                    else
                        MessageBox.Show("Failed to delete from database.");
                }
            }
        }

        // cancel
        private void cancel_Click(object sender, EventArgs e)
        {
            editPanel.Visible = false;
            panel1.Visible = false;
            DeleteButton.Enabled = true;
            grid.Enabled = true;

            cuiTextBox1.Content = "";
            cuiTextBox2.Content = "";
            quantityBox.Content = "";
            cuiTextBox1.Enabled = true;
            isEditMode = false;
            editingItemId = -1;
            addItem.Text = "Add";
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            deletePanel1.Visible = true;
            AddButton.Enabled = false;
            grid.Enabled = false;
        }

        private void deleteItem_Click(object sender, EventArgs e)
        {
            string itemIdInput = cuiTextBox4.Content.Trim();
            if (!int.TryParse(itemIdInput, out int itemId) || itemId < 0)
            {
                MessageBox.Show("Invalid ID. Please enter a valid number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cuiTextBox4.Content = "";
                return;
            }

            bool success = _appServices.InventoryService.DeleteById(itemId);
            if (!success)
            {
                MessageBox.Show("Failed to delete item. It may not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            refreshItems();
            deletePanel1.Visible = false;
            AddButton.Enabled = true;
            grid.Enabled = true;
            cuiTextBox4.Content = "";
        }

        private void cuiButton1_Click(object sender, EventArgs e)
        {
            deletePanel1.Visible = false;
            AddButton.Enabled = true;
            grid.Enabled = true;
            cuiTextBox4.Content = "";
        }

        // Unused event handlers
        private void InventoryPage_Load(object sender, EventArgs e) { }
        private void cuiLabel4_Load(object sender, EventArgs e) { }
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void panel3_Paint(object sender, PaintEventArgs e) { }
        private void deletePanel_Paint(object sender, PaintEventArgs e) { }
        private void cuiTextBox2_ContentChanged(object sender, EventArgs e) { }

        // update btn for the edit panel
        private void cuiButton3_Click(object sender, EventArgs e)
        {
            string quantityInput = quantityBox.Content.Trim();

            if (!int.TryParse(quantityInput, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Invalid Quantity. Please enter a positive number greater than 0.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Get the selected row from the grid
            if (grid.SelectedCells.Count > 0)
            {
                int rowIndex = grid.SelectedCells[0].RowIndex;
                if (rowIndex >= 0)
                {
                    // Get the ItemId from the first column of the selected row
                    object itemIdValue = grid.Rows[rowIndex].Cells["Column1"].Value;

                    if (itemIdValue != null && int.TryParse(itemIdValue.ToString(), out int itemId))
                    {
                        bool s = _appServices.InventoryService.UpdateQuantityById(itemId, quantity);
                        
                    }
                    else
                    {
                        MessageBox.Show("Could not retrieve a valid Item ID from the selected row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }

            // Reset UI state
            editPanel.Visible = false;
            DeleteButton.Enabled = true;
            grid.Enabled = true;
            refreshItems();
            quantityBox.Content = "";
            cuiTextBox1.Content = "";
            cuiTextBox1.Enabled = true;
            addItem.Text = "Add";
        }


        // cancel btn for the edit panel
        private void cuiButton2_Click(object sender, EventArgs e)
        {
            cancel_Click(sender, e);
        }
    }
}
