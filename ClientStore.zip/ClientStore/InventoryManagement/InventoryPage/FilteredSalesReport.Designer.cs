﻿namespace InventoryManagement
{
    partial class FilteredSalesReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle14 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle15 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle13 = new DataGridViewCellStyle();
            dailySales = new DataGridView();
            Column3 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column1 = new DataGridViewTextBoxColumn();
            ExportPDF = new CuoreUI.Controls.cuiButton();
            ((System.ComponentModel.ISupportInitialize)dailySales).BeginInit();
            SuspendLayout();
            // 
            // dailySales
            // 
            dailySales.AllowUserToAddRows = false;
            dailySales.AllowUserToDeleteRows = false;
            dailySales.AllowUserToResizeColumns = false;
            dailySales.AllowUserToResizeRows = false;
            dataGridViewCellStyle11.BackColor = Color.FromArgb(111, 137, 217);
            dailySales.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            dailySales.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dailySales.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dailySales.BackgroundColor = Color.FromArgb(111, 137, 217);
            dailySales.BorderStyle = BorderStyle.None;
            dailySales.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dailySales.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = Color.FromArgb(75, 91, 137);
            dataGridViewCellStyle12.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle12.ForeColor = Color.White;
            dataGridViewCellStyle12.SelectionBackColor = Color.FromArgb(75, 91, 137);
            dataGridViewCellStyle12.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = DataGridViewTriState.True;
            dailySales.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            dailySales.ColumnHeadersHeight = 30;
            dailySales.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dailySales.Columns.AddRange(new DataGridViewColumn[] { Column3, Column6, Column4, Column1 });
            dataGridViewCellStyle14.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = Color.FromArgb(136, 165, 253);
            dataGridViewCellStyle14.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle14.ForeColor = Color.White;
            dataGridViewCellStyle14.SelectionBackColor = Color.FromArgb(194, 208, 249);
            dataGridViewCellStyle14.SelectionForeColor = Color.White;
            dataGridViewCellStyle14.WrapMode = DataGridViewTriState.False;
            dailySales.DefaultCellStyle = dataGridViewCellStyle14;
            dailySales.EnableHeadersVisualStyles = false;
            dailySales.Location = new Point(17, 48);
            dailySales.Name = "dailySales";
            dataGridViewCellStyle15.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle15.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle15.ForeColor = Color.White;
            dataGridViewCellStyle15.SelectionBackColor = SystemColors.ControlText;
            dataGridViewCellStyle15.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = DataGridViewTriState.True;
            dailySales.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            dailySales.RowHeadersVisible = false;
            dailySales.RowTemplate.Height = 50;
            dailySales.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dailySales.Size = new Size(980, 547);
            dailySales.TabIndex = 5;
            dailySales.CellContentClick += dailySales_CellContentClick;
            // 
            // Column3
            // 
            Column3.FillWeight = 50F;
            Column3.HeaderText = "Sales Date";
            Column3.Name = "Column3";
            // 
            // Column6
            // 
            Column6.FillWeight = 70F;
            Column6.HeaderText = "Transactions";
            Column6.Name = "Column6";
            // 
            // Column4
            // 
            Column4.HeaderText = "Total Quantity Sold";
            Column4.Name = "Column4";
            // 
            // Column1
            // 
            dataGridViewCellStyle13.Format = "d";
            dataGridViewCellStyle13.NullValue = null;
            Column1.DefaultCellStyle = dataGridViewCellStyle13;
            Column1.HeaderText = "Total Revenue";
            Column1.Name = "Column1";
            // 
            // ExportPDF
            // 
            ExportPDF.BackColor = Color.Transparent;
            ExportPDF.BackgroundImageLayout = ImageLayout.None;
            ExportPDF.CheckButton = false;
            ExportPDF.Checked = false;
            ExportPDF.CheckedBackground = Color.Transparent;
            ExportPDF.CheckedForeColor = Color.Transparent;
            ExportPDF.CheckedImageTint = Color.Transparent;
            ExportPDF.CheckedOutline = Color.Transparent;
            ExportPDF.Content = "Export To PDF File";
            ExportPDF.Cursor = Cursors.Hand;
            ExportPDF.DialogResult = DialogResult.None;
            ExportPDF.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ExportPDF.ForeColor = Color.WhiteSmoke;
            ExportPDF.HoverBackground = Color.FromArgb(2, 44, 120);
            ExportPDF.HoveredImageTint = Color.Firebrick;
            ExportPDF.HoverForeColor = Color.WhiteSmoke;
            ExportPDF.HoverOutline = Color.Transparent;
            ExportPDF.Image = null;
            ExportPDF.ImageAutoCenter = true;
            ExportPDF.ImageExpand = new Point(7, 7);
            ExportPDF.ImageOffset = new Point(-20, 0);
            ExportPDF.Location = new Point(771, 2);
            ExportPDF.Name = "ExportPDF";
            ExportPDF.NormalBackground = Color.FromArgb(37, 53, 76);
            ExportPDF.NormalForeColor = Color.WhiteSmoke;
            ExportPDF.NormalImageTint = Color.White;
            ExportPDF.NormalOutline = Color.Transparent;
            ExportPDF.OutlineThickness = 1F;
            ExportPDF.PressedBackground = Color.FromArgb(0, 2, 6);
            ExportPDF.PressedForeColor = Color.WhiteSmoke;
            ExportPDF.PressedImageTint = Color.Firebrick;
            ExportPDF.PressedOutline = Color.Transparent;
            ExportPDF.Rounding = new Padding(8);
            ExportPDF.Size = new Size(227, 45);
            ExportPDF.TabIndex = 6;
            ExportPDF.TextAlignment = StringAlignment.Center;
            ExportPDF.TextOffset = new Point(0, 0);
            ExportPDF.Click += ExportPDF_Click;
            // 
            // FilteredSalesReport
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(111, 137, 217);
            ClientSize = new Size(1018, 582);
            Controls.Add(ExportPDF);
            Controls.Add(dailySales);
            ForeColor = Color.White;
            FormBorderStyle = FormBorderStyle.None;
            Name = "FilteredSalesReport";
            Text = "DailySalesReport";
            ((System.ComponentModel.ISupportInitialize)dailySales).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dailySales;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column1;
        private CuoreUI.Controls.cuiButton ExportPDF;
    }
}