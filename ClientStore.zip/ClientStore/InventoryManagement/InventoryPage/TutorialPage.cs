﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Infrastructure.Utilities;

namespace InventoryManagement
{
    public partial class TutorialPage : Form
    {
        private readonly AppServices _appServices;
        public TutorialPage(AppServices appServices)
        {
            InitializeComponent();
            _appServices = appServices;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}
