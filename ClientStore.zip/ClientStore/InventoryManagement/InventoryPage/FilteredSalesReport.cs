﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Core.DTOs;
using Infrastructure.Utilities;

namespace InventoryManagement
{
    public partial class FilteredSalesReport : Form
    {
        private readonly AppServices _appServices;
        public FilteredSalesReport(AppServices appServices)
        {
            InitializeComponent();
            _appServices = appServices;

            // show all the repors from from db
            refreshReports();
        }
        public FilteredSalesReport(AppServices appServices, DateTime start, DateTime end) {
            InitializeComponent();
            _appServices = appServices;

            refreshReports(start, end);
        }

        private void refreshReports() {
            foreach (ReportDTO report in _appServices.SalesDetailsService.GetAllReports())
            {
                // SaleDate, Transaction, TotalQuantitySold, TotalAmount
                dailySales.Rows.Add(report.SaleDate.ToString("dd-MM-yyyy"), report.Transactions.ToString(), report.TotalQuantitySold.ToString(), "$" + report.TotalAmount.ToString());
            }
        }

        private void refreshReports(DateTime start, DateTime end)
        {
            foreach (ReportDTO report in _appServices.SalesDetailsService.GetAllReportsByDates(start, end))
            {
                // SaleDate, Transaction, TotalQuantitySold, TotalAmount
                dailySales.Rows.Add(report.SaleDate.ToString("dd-MM-yyyy"), report.Transactions.ToString(), report.TotalQuantitySold.ToString(), "$" + report.TotalAmount.ToString());
            }
        }

        private void dailySales_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
