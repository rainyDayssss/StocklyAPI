﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Core.DTOs;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using Infrastructure.Utilities;

namespace InventoryManagement
{
    public partial class FilteredSalesReport : Form
    {
        private readonly AppServices _appServices;
        public FilteredSalesReport(AppServices appServices)
        {
            InitializeComponent();
            _appServices = appServices;

            // show all the repors from from db
            refreshReports();
        }
        public FilteredSalesReport(AppServices appServices, DateTime start, DateTime end)
        {
            InitializeComponent();
            _appServices = appServices;

            refreshReports(start, end);
        }

        private void refreshReports()
        {
            foreach (ReportDTO report in _appServices.SalesDetailsService.GetAllReports())
            {
                // SaleDate, Transaction, TotalQuantitySold, TotalAmount
                dailySales.Rows.Add(report.SaleDate.ToString("dd-MM-yyyy"), report.Transactions.ToString(), report.TotalQuantitySold.ToString(), "$" + report.TotalAmount.ToString());
            }
        }

        private void refreshReports(DateTime start, DateTime end)
        {
            foreach (ReportDTO report in _appServices.SalesDetailsService.GetAllReportsByDates(start, end))
            {
                // SaleDate, Transaction, TotalQuantitySold, TotalAmount
                dailySales.Rows.Add(report.SaleDate.ToString("dd-MM-yyyy"), report.Transactions.ToString(), report.TotalQuantitySold.ToString(), "$" + report.TotalAmount.ToString());
            }
        }

        private void dailySales_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ExportPDF_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog
            {
                Filter = "PDF files (.pdf)|.pdf",
                FileName = "SalesReport.pdf"
            };

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                ExportDataGridViewToPDF(dailySales, sfd.FileName);
            }
        }

        private void ExportDataGridViewToPDF(DataGridView dailySales, string fileName)
        {
            try
            {
                using (FileStream stream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    iTextSharp.text.Document pdfDoc = new iTextSharp.text.Document(PageSize.A4, 10f, 10f, 20f, 20f);
                    PdfWriter.GetInstance(pdfDoc, stream);
                    pdfDoc.Open();

                    Paragraph header = new Paragraph("Filtered Sales Report\n\n", FontFactory.GetFont("Arial", 16, iTextSharp.text.Font.BOLD));
                    header.Alignment = Element.ALIGN_CENTER;
                    pdfDoc.Add(header);

                    PdfPTable table = new PdfPTable(dailySales.Columns.Count);
                    table.WidthPercentage = 100;

                    // Add headers
                    foreach (DataGridViewColumn column in dailySales.Columns)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText))
                        {
                            BackgroundColor = BaseColor.LIGHT_GRAY
                        };
                        table.AddCell(cell);
                    }

                    // Add rows
                    foreach (DataGridViewRow row in dailySales.Rows)
                    {
                        if (row.IsNewRow) continue;

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            table.AddCell(cell.Value?.ToString() ?? "");
                        }
                    }

                    pdfDoc.Add(table);
                    pdfDoc.Close();
                    stream.Close();
                }

                MessageBox.Show("PDF exported successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
