﻿using Infrastructure.Utilities;
using InventoryManagement;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClientStore
{
    public partial class Stockly : Form
    {
        public static Panel MainPanel;
        private readonly AppServices _appServices;

        public Stockly(AppServices services)
        {
            InitializeComponent();
            _appServices = services;

            // Debugging: Check if appServices is null
            MainPanel = panel1;

            StartingPage tutorialPage = new StartingPage(_appServices)
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            this.panel1.Controls.Add(tutorialPage);
            tutorialPage.Show();
            

        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

    }
}
