﻿using Infrastructure.Utilities;
using InventoryManagement;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClientStore
{
    public partial class Stockly : Form
    {
        public static Panel MainPanel;
        private readonly AppServices _appServices;

        [Obsolete("For designer only", true)]
        private Stockly()
        {
            InitializeComponent();
            MessageBox.Show(Environment.StackTrace, "Who is calling me?");


            if (LicenseManager.UsageMode != LicenseUsageMode.Designtime)
            {
                throw new InvalidOperationException("Stockly must be initialized with AppServices.");
            }
        }
        public Stockly(AppServices services)
        {
            InitializeComponent();
            _appServices = services;

            // Debugging: Check if appServices is null
            MainPanel = panel1;
            if (_appServices == null)
            {
                MessageBox.Show("AppServices is null in Stockly form.");
            }
            

            else
            {
                MessageBox.Show("AppServices is not null in Stockly form.");
                StartingPage tutorialPage = new StartingPage(_appServices)
                {
                    Dock = DockStyle.Fill,
                    TopLevel = false,
                    TopMost = true
                };
                this.panel1.Controls.Add(tutorialPage);
                tutorialPage.Show();
            }

        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

    }
}
