﻿namespace InventoryManagement
{
    partial class ProductPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            productGrid = new FlowLayoutPanel();
            SuspendLayout();
            // 
            // productGrid
            // 
            productGrid.Location = new Point(-1, -1);
            productGrid.Name = "productGrid";
            productGrid.Size = new Size(1017, 710);
            productGrid.TabIndex = 19;
            productGrid.Paint += productGrid_Paint;
            // 
            // ProductPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(111, 137, 217);
            ClientSize = new Size(1019, 679);
            Controls.Add(productGrid);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ProductPage";
            Text = "TutorialPage";
            Load += ProductPage_Load;
            ResumeLayout(false);
        }

        #endregion

        private FlowLayoutPanel productGrid;
    }
}