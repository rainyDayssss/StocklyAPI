﻿// ProductPage.cs (updated UI with skyblue and darkblue themed quantity input dialog)

using Core.Model;
using CuoreUI.Controls;
using Infrastructure.Utilities;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Core.DTOs;
using GroceryCalcApp.Models;
using GroceryCalcApp.Services;

namespace InventoryManagement
{
    public partial class ProductPage : Form
    {
        private readonly AppServices _appServices;
        private PurchaseSession _purchaseSession;

        public ProductPage(AppServices services, PurchaseSession session)
        {
            _appServices = services;
            InitializeComponent();
            AddProductPanels();
            _purchaseSession = session;
        }

        // show all the products from Inventory Table
        private void AddProductPanels()
        {
            productGrid.AutoScroll = true;
            productGrid.WrapContents = true;

            List<InventoryDTO> inventoryDTOs = _appServices.InventoryService.GetAll().ToList();

            foreach (InventoryDTO invDTO in inventoryDTOs)
            {
                cuiPanel newProductPanel = new cuiPanel
                {
                    Size = new Size(242, 300),
                    BackColor = Color.Transparent,
                    PanelColor = Color.FromArgb(44, 62, 80), // DarkBlue
                    PanelOutlineColor = Color.FromArgb(44, 62, 80),
                    Margin = new Padding(40)
                };

                cuiPictureBox productPicture = new cuiPictureBox
                {
                    Size = new Size(177, 143),
                    BackColor = Color.WhiteSmoke,
                    Location = new Point(33, 17)
                };
                newProductPanel.Controls.Add(productPicture);

                Label productLabel = new Label
                {
                    Text = $"{invDTO.ItemName} stock: {invDTO.Quantity}",
                    TextAlign = ContentAlignment.TopLeft,
                    Size = new Size(210, 35),
                    ForeColor = Color.White,
                    Font = new Font("Arial", 14, FontStyle.Bold),
                    Location = new Point(28, 168),
                    BackColor = Color.Transparent
                };
                newProductPanel.Controls.Add(productLabel);

                Label productPrice = new Label
                {
                    Text = $"${invDTO.Price:0.00}",
                    Size = new Size(133, 32),
                    ForeColor = Color.White,
                    Font = new Font("Arial", 14, FontStyle.Bold),
                    Location = new Point(30, 200)
                };
                newProductPanel.Controls.Add(productPrice);

                cuiButtonGroup addButton = new cuiButtonGroup
                {
                    Font = new Font("Arial", 15, FontStyle.Bold),
                    Content = invDTO.Quantity > 0 ? "Add" : "Out of Stock",
                    Location = new Point(34, 232),
                    Size = new Size(177, 46),
                    HoverBackground = Color.SkyBlue,
                    PressedBackground = Color.FromArgb(37, 53, 76),
                    NormalBackground = Color.FromArgb(44, 62, 80),
                    HoverForeColor = Color.WhiteSmoke,
                    NormalForeColor = Color.WhiteSmoke,
                    PressedForeColor = Color.WhiteSmoke,
                    CheckedBackground = Color.FromArgb(0, 192, 0),
                    CheckedOutline = Color.Transparent,
                    Cursor = Cursors.Hand,
                    Tag = invDTO,
                    Enabled = invDTO.Quantity > 0
                };

                if (invDTO.Quantity > 0)
                    addButton.Click += AddButton_Click;

                newProductPanel.Controls.Add(addButton);
                productGrid.Controls.Add(newProductPanel);
                productGrid.Padding = new Padding(10);
            }
        }


        // maybe the add btn
        private void AddButton_Click(object sender, EventArgs e)
        {
            cuiButtonGroup btn = (cuiButtonGroup)sender;
            if (btn.Tag is InventoryDTO invDTO)
            {
                using (Form inputDialog = new Form())
                {
                    inputDialog.Text = $"Enter Quantity";
                    inputDialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                    inputDialog.StartPosition = FormStartPosition.CenterParent;
                    inputDialog.Size = new Size(300, 150);
                    inputDialog.BackColor = Color.FromArgb(44, 62, 80);

                    Label label = new Label()
                    {
                        Text = "Quantity:",
                        Location = new Point(20, 20),
                        ForeColor = Color.White,
                        Font = new Font("Arial", 10),
                        AutoSize = true
                    };
                    inputDialog.Controls.Add(label);

                    NumericUpDown inputBox = new NumericUpDown()
                    {
                        Location = new Point(100, 18),
                        Width = 150,
                        Minimum = 1,
                        Maximum = 1000,
                        TextAlign = HorizontalAlignment.Left
                    };
                    inputDialog.Controls.Add(inputBox);

                    Button okButton = new Button()
                    {
                        Text = "OK",
                        DialogResult = DialogResult.OK,
                        Location = new Point(100, 60),
                        BackColor = Color.SkyBlue,
                        ForeColor = Color.Black
                    };
                    inputDialog.Controls.Add(okButton);
                    inputDialog.AcceptButton = okButton;

                    if (inputDialog.ShowDialog() == DialogResult.OK)
                    {
                        int quantity = (int)inputBox.Value;

                        int alreadyPurchased = _purchaseSession.GetPurchasedQuantity(invDTO.ItemId);
                        int remaining = invDTO.Quantity - alreadyPurchased;

                        if (quantity > remaining)
                        {
                            MessageBox.Show(
                                $"You've entered greater than the {invDTO.Quantity} available stock.",
                                "Quantity Exceeded",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning
                            );
                            return;
                        }

                        if (quantity == remaining)
                        {
                            DialogResult confirm = MessageBox.Show(
                                "You're about to purchase all available stock of this item. Proceed?",
                                "Confirm Full Purchase",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Information
                            );

                            if (confirm != DialogResult.Yes)
                                return;
                        }

                        // Add item to session cart
                        _purchaseSession.AddItem(invDTO, quantity);

                        // Debug
                        MessageBox.Show(
                               $"You added the item {invDTO.ItemName} to the cart",
                               "Successful",
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Information
                        );

                        // Update button UI
                        btn.Content = "In Cart";
                        btn.Enabled = false;

                        // Update stock label
                        Label stockLabel = btn.Parent.Controls
                            .OfType<Label>()
                            .FirstOrDefault(l => l.Text.StartsWith(invDTO.ItemName + " stock:"));

                        if (stockLabel != null)
                            stockLabel.Text = $"{invDTO.ItemName} stock: {remaining - quantity}";
                    }
                }
            }
        }






        private void productGrid_Paint(object sender, PaintEventArgs e) { }
        private void ProductPage_Load(object sender, EventArgs e) { }
    }
}
