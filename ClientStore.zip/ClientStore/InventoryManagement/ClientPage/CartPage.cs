﻿using CuoreUI.Components;
using System;
using System.Windows.Forms;
using CuoreUI;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Infrastructure.Utilities;


namespace InventoryManagement
{
    public partial class CartPage : Form
    {
        private readonly AppServices _appServices;
        public CartPage(AppServices appServices)
        {
            InitializeComponent();
            _appServices = appServices;
            // Add rows to DataGridView
            for (int i = 0; i < 40; i++)
            {
                grid.Rows.Add("Item " + i, i * 40, (10 + i));
            }
            // Editing the value of subtotal, discount, and total
            subTotal.Content = "$40.00";
            discountAmount.Content = "$20.00";
            totalAmount.Content = "$20.00";
        }

        private void cuiLabel1_Load(object sender, EventArgs e)
        {

        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            grid.Enabled = false;
        }

        private void addItem_Click(object sender, EventArgs e)
        {
            StartPage.MainPanel.Controls.Clear();
            ReceiptPage itemPage = new ReceiptPage(_appServices) { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            StartPage.MainPanel.Controls.Add(itemPage);
            itemPage.Show();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cancel_Click(object sender, EventArgs e)
        {


        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            grid.Enabled = false;
        }

        private void cuiLabel4_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            // Check if the clicked row is a button row
            if (grid.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                // Remove the  row
                grid.Rows.RemoveAt(e.RowIndex);
            }


        }

        private void cuiLabel2_Load(object sender, EventArgs e)
        {

        }

        private void CartPage_Load(object sender, EventArgs e)
        {

        }

        private void CartPage_Load_1(object sender, EventArgs e)
        {

        }

        private void cuiLabel8_Load(object sender, EventArgs e)
        {

        }
    }
}
