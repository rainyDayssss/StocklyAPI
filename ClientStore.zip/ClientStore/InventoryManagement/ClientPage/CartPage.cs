﻿using CuoreUI.Components;
using System;
using System.Windows.Forms;
using CuoreUI;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Infrastructure.Utilities;
using GroceryCalcApp.Services;
using Core.DTOs;
using Core.Model;


namespace InventoryManagement
{
    public partial class CartPage : Form
    {
        private readonly AppServices _appServices;
        private PurchaseSession _purchaseSession;
        public CartPage(AppServices appServices, PurchaseSession session)
        {
            InitializeComponent();
            _appServices = appServices;
            _purchaseSession = session;
            // Add rows to DataGridView
            foreach (InventoryDTO inv in session.GetAllItems())
            {
                // Debug
                // Name, Id,  PuchaseQuantity, Price, 
                grid.Rows.Add(inv.ItemName, inv.PurchaseQuantity, "$" + inv.Price);
            }
            // Editing the value of subtotal, discount, and total
            subTotal.Content = "$" + session.GetSubtotal().ToString("0.00");
            discountAmount.Content = "$" + session.GetDiscountAmount().ToString("0.00");
            totalAmount.Content = "$" + session.GetFinalTotal().ToString("0.00");
        }

        private void cuiLabel1_Load(object sender, EventArgs e)
        {

        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            grid.Enabled = false;
        }

        // Get receipt btn or make purchase btn
        private void addItem_Click(object sender, EventArgs e)
        {
            // Check if there are no items in the cart
            if (_purchaseSession.GetAllItems().Count == 0)
            {
                // Display a message box to notify the user
                MessageBox.Show("There are no products in your cart.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // Debug
                // Proceed with the normal flow to display the receipt page
                // Add the sale to the sales table and add the total amount of the sale
                int id = _appServices.SalesService.AddSales(_purchaseSession.TotalFinal);

                // Iterate over all items in the purchase session
                foreach (InventoryDTO item in _purchaseSession.GetAllItems())
                {
                    // Minus Quantity in the database
                    _appServices.InventoryService.UpdateQuantityById(item.ItemId, item.Quantity - item.PurchaseQuantity);

                    // For each item, add a SalesDetails entry
                    _appServices.SalesDetailsService.Add(new SalesDetails
                    {
                        SalesId = id, // The SalesId is the ID of the sale you just added
                        ItemId = item.ItemId, // ItemId for each item in the cart
                        QuantitySold = item.PurchaseQuantity, // The quantity of each item purchased
                        SubTotal = _purchaseSession.GetSubtotal() // Calculate the subtotal for each item
                    });
                }

                _purchaseSession.SaleDate = DateTime.Now;
                StartPage.MainPanel.Controls.Clear();
                ReceiptPage itemPage = new ReceiptPage(_appServices, _purchaseSession) { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
                StartPage.MainPanel.Controls.Add(itemPage);
                itemPage.Show();
            }
        }


        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cancel_Click(object sender, EventArgs e)
        {


        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            grid.Enabled = false;
        }

        private void cuiLabel4_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        // dlete btn
        private void grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (grid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
            {
                string itemName = grid.Rows[e.RowIndex].Cells[0].Value?.ToString();
                if (!string.IsNullOrEmpty(itemName))
                {
                    // Remove from session
                    InventoryDTO itemToRemove = _purchaseSession.GetAllItems()
                        .FirstOrDefault(i => i.ItemName.Equals(itemName, StringComparison.OrdinalIgnoreCase));

                    if (itemToRemove != null)
                    {
                        _purchaseSession.DeleteItemById(itemToRemove.Id);
                    }

                    // Remove from grid
                    grid.Rows.RemoveAt(e.RowIndex);

                    // Recalculate totals
                    subTotal.Content = "$" + _purchaseSession.GetSubtotal().ToString("0.00");
                    discountAmount.Content = "$" + _purchaseSession.GetDiscountAmount().ToString("0.00");
                    totalAmount.Content = "$" + _purchaseSession.GetFinalTotal().ToString("0.00");
                }
            }
        }


        private void cuiLabel2_Load(object sender, EventArgs e)
        {

        }

        private void CartPage_Load(object sender, EventArgs e)
        {

        }

        private void CartPage_Load_1(object sender, EventArgs e)
        {

        }

        private void cuiLabel8_Load(object sender, EventArgs e)
        {

        }

        private void totalAmount_Load(object sender, EventArgs e)
        {

        }
    }
}