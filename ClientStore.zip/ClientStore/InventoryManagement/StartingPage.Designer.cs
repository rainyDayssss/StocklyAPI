﻿namespace ClientStore
{
    partial class StartingPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cuiPanel1 = new CuoreUI.Controls.cuiPanel();
            cuiLabel2 = new CuoreUI.Controls.cuiLabel();
            cuiLabel4 = new CuoreUI.Controls.cuiLabel();
            cuiLabel1 = new CuoreUI.Controls.cuiLabel();
            clientButton = new CuoreUI.Controls.cuiButton();
            adminButton = new CuoreUI.Controls.cuiButton();
            cuiPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // cuiPanel1
            // 
            cuiPanel1.BackColor = Color.FromArgb(64, 79, 115);
            cuiPanel1.Controls.Add(cuiLabel2);
            cuiPanel1.Controls.Add(cuiLabel4);
            cuiPanel1.Controls.Add(cuiLabel1);
            cuiPanel1.ForeColor = Color.Transparent;
            cuiPanel1.Location = new Point(-1, 1);
            cuiPanel1.Name = "cuiPanel1";
            cuiPanel1.OutlineThickness = 1F;
            cuiPanel1.PanelColor = Color.Transparent;
            cuiPanel1.PanelOutlineColor = Color.FromArgb(64, 79, 115);
            cuiPanel1.Rounding = new Padding(8);
            cuiPanel1.Size = new Size(526, 679);
            cuiPanel1.TabIndex = 0;
            // 
            // cuiLabel2
            // 
            cuiLabel2.AutoValidate = AutoValidate.EnablePreventFocusChange;
            cuiLabel2.BackColor = Color.Transparent;
            cuiLabel2.BackgroundImage = Properties.Resources.icons8_grid_100;
            cuiLabel2.BackgroundImageLayout = ImageLayout.Stretch;
            cuiLabel2.Content = "";
            cuiLabel2.Font = new Font("Arial", 48F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cuiLabel2.ForeColor = Color.White;
            cuiLabel2.HorizontalAlignment = StringAlignment.Center;
            cuiLabel2.Location = new Point(33, 227);
            cuiLabel2.Margin = new Padding(4, 3, 4, 3);
            cuiLabel2.Name = "cuiLabel2";
            cuiLabel2.Size = new Size(159, 158);
            cuiLabel2.TabIndex = 13;
            cuiLabel2.VerticalAlignment = StringAlignment.Center;
            // 
            // cuiLabel4
            // 
            cuiLabel4.AutoValidate = AutoValidate.EnablePreventFocusChange;
            cuiLabel4.BackgroundImageLayout = ImageLayout.None;
            cuiLabel4.Content = "Stockly\\ –\\ Smarter\\ stock\\.\\ Smoother\\ sales";
            cuiLabel4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cuiLabel4.ForeColor = Color.White;
            cuiLabel4.HorizontalAlignment = StringAlignment.Center;
            cuiLabel4.Location = new Point(0, 376);
            cuiLabel4.Margin = new Padding(4, 3, 4, 3);
            cuiLabel4.Name = "cuiLabel4";
            cuiLabel4.Size = new Size(503, 55);
            cuiLabel4.TabIndex = 12;
            cuiLabel4.VerticalAlignment = StringAlignment.Center;
            // 
            // cuiLabel1
            // 
            cuiLabel1.AutoValidate = AutoValidate.EnablePreventFocusChange;
            cuiLabel1.BackgroundImageLayout = ImageLayout.None;
            cuiLabel1.Content = "Stockly";
            cuiLabel1.Font = new Font("Arial", 48F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cuiLabel1.ForeColor = Color.White;
            cuiLabel1.HorizontalAlignment = StringAlignment.Center;
            cuiLabel1.Location = new Point(151, 258);
            cuiLabel1.Margin = new Padding(4, 3, 4, 3);
            cuiLabel1.Name = "cuiLabel1";
            cuiLabel1.Size = new Size(310, 112);
            cuiLabel1.TabIndex = 3;
            cuiLabel1.VerticalAlignment = StringAlignment.Center;
            // 
            // clientButton
            // 
            clientButton.BackColor = Color.Transparent;
            clientButton.BackgroundImageLayout = ImageLayout.None;
            clientButton.CheckButton = false;
            clientButton.Checked = false;
            clientButton.CheckedBackground = Color.Transparent;
            clientButton.CheckedForeColor = Color.Transparent;
            clientButton.CheckedImageTint = Color.Transparent;
            clientButton.CheckedOutline = Color.Transparent;
            clientButton.Content = "Customer";
            clientButton.DialogResult = DialogResult.None;
            clientButton.Font = new Font("Arial", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            clientButton.ForeColor = Color.White;
            clientButton.HoverBackground = Color.FromArgb(30, 89, 172);
            clientButton.HoveredImageTint = Color.FromArgb(96, 138, 227);
            clientButton.HoverForeColor = Color.White;
            clientButton.HoverOutline = Color.Transparent;
            clientButton.Image = null;
            clientButton.ImageAutoCenter = true;
            clientButton.ImageExpand = new Point(9, 9);
            clientButton.ImageOffset = new Point(-40, 0);
            clientButton.Location = new Point(635, 382);
            clientButton.Name = "clientButton";
            clientButton.NormalBackground = Color.FromArgb(32, 81, 149);
            clientButton.NormalForeColor = Color.White;
            clientButton.NormalImageTint = Color.White;
            clientButton.NormalOutline = Color.Transparent;
            clientButton.OutlineThickness = 1F;
            clientButton.PressedBackground = Color.FromArgb(0, 42, 100);
            clientButton.PressedForeColor = Color.White;
            clientButton.PressedImageTint = Color.FromArgb(96, 138, 227);
            clientButton.PressedOutline = Color.Transparent;
            clientButton.Rounding = new Padding(8);
            clientButton.Size = new Size(478, 110);
            clientButton.TabIndex = 14;
            clientButton.TextAlignment = StringAlignment.Center;
            clientButton.TextOffset = new Point(0, 0);
            clientButton.Click += clientButton_Click;
            // 
            // adminButton
            // 
            adminButton.BackColor = Color.Transparent;
            adminButton.BackgroundImageLayout = ImageLayout.None;
            adminButton.CheckButton = false;
            adminButton.Checked = false;
            adminButton.CheckedBackground = Color.Transparent;
            adminButton.CheckedForeColor = Color.Transparent;
            adminButton.CheckedImageTint = Color.Transparent;
            adminButton.CheckedOutline = Color.Transparent;
            adminButton.Content = "Admin";
            adminButton.DialogResult = DialogResult.None;
            adminButton.Font = new Font("Arial", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            adminButton.ForeColor = Color.White;
            adminButton.HoverBackground = Color.FromArgb(55, 55, 56);
            adminButton.HoveredImageTint = Color.FromArgb(96, 138, 227);
            adminButton.HoverForeColor = Color.White;
            adminButton.HoverOutline = Color.Transparent;
            adminButton.Image = null;
            adminButton.ImageAutoCenter = true;
            adminButton.ImageExpand = new Point(7, 7);
            adminButton.ImageOffset = new Point(-20, 0);
            adminButton.Location = new Point(635, 190);
            adminButton.Name = "adminButton";
            adminButton.NormalBackground = Color.FromArgb(44, 50, 58);
            adminButton.NormalForeColor = Color.White;
            adminButton.NormalImageTint = Color.White;
            adminButton.NormalOutline = Color.Transparent;
            adminButton.OutlineThickness = 1F;
            adminButton.PressedBackground = Color.FromArgb(22, 24, 26);
            adminButton.PressedForeColor = Color.White;
            adminButton.PressedImageTint = Color.FromArgb(96, 138, 227);
            adminButton.PressedOutline = Color.Transparent;
            adminButton.Rounding = new Padding(8);
            adminButton.Size = new Size(478, 110);
            adminButton.TabIndex = 15;
            adminButton.TextAlignment = StringAlignment.Center;
            adminButton.TextOffset = new Point(0, 0);
            adminButton.Click += adminButton_Click;
            // 
            // StartingPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(111, 137, 217);
            ClientSize = new Size(1264, 681);
            Controls.Add(clientButton);
            Controls.Add(cuiPanel1);
            Controls.Add(adminButton);
            FormBorderStyle = FormBorderStyle.None;
            Name = "StartingPage";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "StartingPage";
            cuiPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private CuoreUI.Controls.cuiPanel cuiPanel1;
        private CuoreUI.Controls.cuiLabel cuiLabel1;
        private CuoreUI.Controls.cuiLabel cuiLabel2;
        private CuoreUI.Controls.cuiLabel cuiLabel4;
        private CuoreUI.Controls.cuiButton clientButton;
        private CuoreUI.Controls.cuiButton adminButton;
    }
}