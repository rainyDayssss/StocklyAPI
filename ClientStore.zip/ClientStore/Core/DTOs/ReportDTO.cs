﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.DTOs
{
    public class ReportDTO
    {
        public DateTime SaleDate { get; set; } 
        public int Transactions { get; set; }
        public int TotalQuantitySold { get; set; }
        public decimal TotalAmount { get; set; }
    }
}
