﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.DTOs
{
    public class SalesDetailsDTO
    {
        public int Id { set; get; }
        public int ItemId { set; get; }
        public int SaleId { set; get; }
        public DateTime SaleDate { set; get; }
        public string ItemName { set; get; }
        public decimal Price { set; get; }
        public int QuantitySold { set; get; }
        public decimal SubTotal { set; get; }
        public decimal TotalAmount { set; get; }
       
        public SalesDetailsDTO() { }
        public SalesDetailsDTO(int id, DateTime saleDate, string itemName, decimal price, int quantitySold, decimal subTotal)
        {
            Id = id;
            SaleDate = saleDate;
            ItemName = itemName;
            Price = price;
            QuantitySold = quantitySold;
            SubTotal = subTotal;
        }
    }
}
