﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Model
{
    public class SalesDetails
    {
        public int Id { set; get; }
        public int SalesId { set; get; }
        public int ItemId { set; get; }
        public int QuantitySold { set; get; }
        public decimal SubTotal { set; get; }
        public SalesDetails() { }
        public SalesDetails(int id, int salesId, int itemId, int quantitySold, decimal subToal) {
            Id = id;
            SalesId = salesId;
            ItemId = itemId;
            QuantitySold = quantitySold;
            SubTotal = subToal;
        }
    }
}
