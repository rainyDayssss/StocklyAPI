﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Core.Model
{
    public class Inventory
    {
        public int Id { set;  get; }
        public int ItemId { set; get; }
        public int Quantity { set; get; }

        public Inventory() { }
        public Inventory(int id, int itemId, int quantity) {
            Id = id;
            ItemId = itemId;
            Quantity = quantity;
        }
    }
}
