﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroceryCalcApp.Exceptions
{
    public class ItemNotFoundException : Exception 
    {
        public ItemNotFoundException() : base("Item was not found!") { }
        public ItemNotFoundException(String message) : base(message) { }

    }
}
