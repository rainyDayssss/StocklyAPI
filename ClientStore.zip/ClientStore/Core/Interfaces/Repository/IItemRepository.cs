﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Model;

namespace Core.Interfaces.Repository
{
    public interface IItemRepository
    {
        IEnumerable<Item> GetAll();
        Item? GetById(int id);
        bool Add(Item item);
        bool DeleteById(int id);
        bool UpdateNameById(int id, string name);
        bool UpdatePriceById(int id, decimal price);
    }
}
