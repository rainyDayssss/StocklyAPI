﻿select * from Inventory

select * from Item

select * from Sales

select * from SalesDetails


SELECT 
    CAST(s.SaleDate AS DATE) AS SaleDate,
    COUNT(DISTINCT s.Id) AS Transactions,
    SUM(sd.QuantitySold) AS TotalQuantitySold,
    SUM(s.TotalAmount) AS TotalAmount
FROM Sales s
JOIN SalesDetails sd ON s.Id = sd.SalesId
GROUP BY CAST(s.SaleDate AS DATE)
ORDER BY SaleDate DESC;

SELECT 
    s.Id AS SaleId,
    CAST(s.SaleDate AS DATE) AS SaleDate,
    SUM(sd.QuantitySold) AS TotalQuantitySold,
    s.TotalAmount
FROM Sales s
JOIN SalesDetails sd ON s.Id = sd.SalesId
GROUP BY s.Id, s.SaleDate, s.TotalAmount
ORDER BY SaleDate DESC;

