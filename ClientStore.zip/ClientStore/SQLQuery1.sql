﻿
create database Test2

use Test2;

create table Item (
	Id int primary key identity(1,1),
	Name varchar(255) not null, 
	Price decimal(10,2) not null check (Price >= 0) -- Prevent negative prices
);

create table Inventory (
	Id int primary key identity(1,1),
	ItemId int not null,
	Quantity int not null check (Quantity >= 0), -- Prevent negative quantities
	
	constraint Fk_Inventory_Item_ID foreign key (ItemID) references Item(ID) on delete cascade -- automatically delete item a if item a is deleted from Item table
);

create table Sales (
	Id int primary key identity(1,1),
	SaleDate datetime default getDate(),
	TotalAmount decimal(10,2) default 0
);

create table SalesDetails (
	Id int primary key identity(1,1),
	ItemId int not null,
	SalesId int not null,
	QuantitySold int not null,
	SubTotal decimal(10,2) not null, -- quantity sold * Item(Price)
	
	constraint Fk_SalesDetails_Sales_Id foreign key (SalesId) references Sales(Id)
);

select * from item
select * from Inventory
select * from Sales
select * from SalesDetails

SELECT 
    s.SaleDate,
	s.Id AS SaleId,
    s.TotalAmount,
    sd.ItemId,
    sd.QuantitySold,
    sd.SubTotal
FROM Sales s
INNER JOIN SalesDetails sd ON s.Id = sd.SalesId;

SELECT 
    CAST(s.SaleDate AS DATE) AS SaleDate,
    COUNT(DISTINCT s.Id) AS Transactions,
    SUM(DISTINCT s.TotalAmount) AS TotalAmount,
    SUM(sd.QuantitySold) AS TotalQuantitySold
FROM Sales s
INNER JOIN SalesDetails sd ON s.Id = sd.SalesId
GROUP BY CAST(s.SaleDate AS DATE)
ORDER BY SaleDate DESC;
