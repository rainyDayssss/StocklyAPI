﻿select * from SalesDetails

select * from Sales;

select 
                                cast(s.SaleDate as Date) as SaleDate,
                                count(distinct s.Id) as Transactions,
                                sum(sd.QuantitySold) as TotalQuantitySold,
                                sum(s.TotalAmount) as TotalAmount
                           from Sales s
                           join SalesDetails sd on s.Id = sd.SalesId
                           group by cast(s.SaleDate as Date)
                           order by SaleDate desc


select 
    Inventory.Id, 
    Item.Name as ItemName, 
    Item.Price,
    Inventory.Quantity 
from Inventory 
inner join Item on Inventory.ItemId = Item.Id