﻿// See https://aka.ms/new-console-template for more information
using Infrastructure.Services;
using Infrastructure.Utilities;
using Infrastructure.Repositories;
using Core.DTOs;
using System;

Console.WriteLine("Hello, World!");


var itemRepository = new ItemRepository(Config.conStr);
var inventoryRepository = new InventoryRepository(Config.conStr);
var salesRepository = new SalesRepository(Config.conStr);
var salesDetailsRepository = new SalesDetailsRepository(Config.conStr);

var itemService = new ItemService(itemRepository);
var inventoryService = new InventoryService(inventoryRepository);
var salesService = new SalesService(salesRepository);
var salesDetailsService = new SalesDetailsService(salesDetailsRepository);

// Create AppServices manually
var appServices = new AppServices(itemService, inventoryService, salesService, salesDetailsService);

foreach (InventoryDTO i in appServices.InventoryService.GetAll()) { 
    Console.WriteLine($"{i.ItemName} {i.Price} {i.Quantity}");
}
