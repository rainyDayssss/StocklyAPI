﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Interfaces.Repository;
using Core.Interfaces.Service;
using Core.Model;
using Infrastructure.Repositories;

namespace Infrastructure.Services
{
    public class ItemService : IItemService
    {
        private readonly IItemRepository _itemRepo;
        public ItemService(IItemRepository itemRepo) {
            _itemRepo = itemRepo;
        }
        public bool Add(Item item)
        {
            return _itemRepo.Add(item);
        }

        public bool DeleteById(int id)
        {
            return _itemRepo.DeleteById(id);
        }

        public IEnumerable<Item> GetAll()
        {
            return _itemRepo.GetAll();
        }

        public Item? GetById(int id)
        {
            return _itemRepo.GetById(id);
        }

        public bool UpdateNameById(int id, string name)
        {
            return _itemRepo.UpdateNameById(id, name);
        }

        public bool UpdatePriceById(int id, decimal price)
        {
            return _itemRepo.UpdatePriceById(id, price);
        }

        public bool Update(Item item) { 
            return _itemRepo.Update(item);
        }
    }
}
