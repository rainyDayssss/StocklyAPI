﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Interfaces.Repository;
using Core.Interfaces.Service;


namespace Infrastructure.Services
{
    public class SalesService : ISalesService
    {
        private readonly ISalesRepository _salesRepo;
        public SalesService(ISalesRepository salesRepository) { 
            _salesRepo = salesRepository;
        }

        public int AddSales(decimal totalAmount)
        {
            return _salesRepo.AddSales(totalAmount);
        }

        public bool UpdateTotalAmountById(int id, decimal totalAmount)
        {
            return _salesRepo.UpdateTotalAmountById(id, totalAmount);
        }
    }
}
