﻿namespace GroceryCalcApp.Services
{
    public class DiscountCalculatorService
    {
        public decimal GetDiscountRate(decimal total)
        {
            if (total > 500)
                return 0.20m;
            else if (total > 200)
                return 0.15m;
            else if (total > 100)
                return 0.10m;
            return 0.0m;
        }

        public decimal CalculateDiscount(decimal total)
        {
            var rate = GetDiscountRate(total);
            return total * rate;
        }
    }
}
