﻿using Core.DTOs;
using Core.Model;
using GroceryCalcApp.Models;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace GroceryCalcApp.Services
{
    public class PurchaseSession
    {
        private readonly Dictionary<int, (InventoryDTO item, int quantity)> _cart;
        private readonly DiscountCalculatorService _discountService;

        public decimal Subtotal { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal TotalFinal { get; set; }
        public DateTime SaleDate { get; set; }

        public PurchaseSession(DiscountCalculatorService discountService)
        {
            _cart = new Dictionary<int, (InventoryDTO, int)>();
            _discountService = discountService;
        }

        public void AddItem(InventoryDTO item, int quantity)
        {
            if (_cart.ContainsKey(item.ItemId))
            {
                _cart[item.ItemId] = (_cart[item.ItemId].item, _cart[item.ItemId].quantity + quantity);
            }
            else
            {
                _cart[item.ItemId] = (item, quantity);
            }
        }

        public int GetPurchasedQuantity(int itemId)
        {
            return _cart.TryGetValue(itemId, out var data) ? data.quantity : 0;
        }

        public List<InventoryDTO> GetAllItems()
        {
            return _cart.Select(x =>
            {
                var (item, quantity) = x.Value;
                item.PurchaseQuantity = quantity; // for legacy use
                return item;
            }).ToList();
        }

        public void DeleteItemById(int id)
        {
            _cart.Remove(id);
        }

        public decimal GetSubtotal()
        {
            return _cart.Sum(kvp => kvp.Value.item.Price * kvp.Value.quantity);
        }

        public decimal GetDiscount() => _discountService.CalculateDiscount(GetSubtotal());

        public decimal GetDiscountAmount()
        {
            DiscountAmount = GetDiscount();
            return DiscountAmount;
        }

        public decimal GetFinalTotal()
        {
            TotalFinal = GetSubtotal() - GetDiscount();
            return TotalFinal;
        }

        public void RestartSession() => _cart.Clear();
    }

}
