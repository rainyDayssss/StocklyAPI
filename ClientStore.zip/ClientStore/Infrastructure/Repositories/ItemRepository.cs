﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Interfaces.Repository;
using Core.Model;
using Microsoft.Data.SqlClient;

namespace Infrastructure.Repositories
{
    public class ItemRepository : IItemRepository
    {
        private readonly string _conStr;

        public ItemRepository(string connStr) {
            _conStr = connStr;
        }

        public bool Add(Item item)
        {
            string query = $"insert into Item (Name, Price) values (@Name, @Price)";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Name", item.Name);
                    cmd.Parameters.AddWithValue("@Price", item.Price);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
        }

        public bool DeleteById(int id)
        {
            string query = $"delete from Item where Id = @Id";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Id", id);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
        }

        public IEnumerable<Item> GetAll()
        {
            string query = "select * from Item";
            List<Item> items = new List<Item>();
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                items.Add(new Item
                                {
                                    Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                    Name = reader.GetString(reader.GetOrdinal("Name")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price"))
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        // throw error
                        Console.WriteLine(ex.Message);
                    }
                }

                return items;
            }
        }

        public Item? GetById(int id)
        {
            string query = $"select * from Item where Id = @Id";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Id", id);
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read()) {
                                return new Item
                                {
                                    Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                    Name = reader.GetString(reader.GetOrdinal("Name")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price"))
                                };
                            }
                            return null;
                        }
                    }
                }
                catch (Exception)
                {
                    return null;
                }
            }
        }

        public bool UpdateNameById(int id, string name)
        {
            string query = $"update Item set Name = @Name where Id = @Id";
            using (SqlConnection con = new SqlConnection(_conStr)) {
                try
                {
                    using SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Id", id);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
                catch (Exception)
                {
                    return false;
                }
            }

        }

        public bool UpdatePriceById(int id, decimal price)
        {
            string query = $"update Item set Price = @Price where Id = @Id";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.Parameters.AddWithValue("@Id", id);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
                catch (Exception)
                {
                    return false;
                }
            }

        }

        public bool Update(Item item) {
            string query = $"update Item set Name = @Name, Price = @Price where Id = @Id";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Name", item.Name);
                    cmd.Parameters.AddWithValue("@Price", item.Price);
                    cmd.Parameters.AddWithValue("@Id", item.Id);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }
    }
}
