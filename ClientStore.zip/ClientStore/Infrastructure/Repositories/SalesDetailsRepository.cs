﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Interfaces.Repository;
using Core.Model;
using Core.DTOs;
using Microsoft.Data.SqlClient;

namespace Infrastructure.Repositories
{
    public class SalesDetailsRepository : ISalesDetailsRepository
    {
        private readonly string _conStr;
        public SalesDetailsRepository(string conStr)
        {
            _conStr = conStr;
        }
        public bool Add(SalesDetails salesDetails)
        {
            string query = @"insert into SalesDetails 
                            (SalesId, ItemId, QuantitySold, SubTotal)  
                            values (@SalesId, @ItemId, @QuantitySold, @SubTotal)";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@SalesId", salesDetails.SalesId);
                        cmd.Parameters.AddWithValue("@ItemId", salesDetails.ItemId);
                        cmd.Parameters.AddWithValue("@QuantitySold", salesDetails.QuantitySold);
                        cmd.Parameters.AddWithValue("@SubTotal", salesDetails.SubTotal);
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public IEnumerable<SalesDetailsDTO> GetAll()
        {
            string query = @"select 
                                sd.Id,
                                s.SaleDate,
                                i.Name as ItemName,
                                i.Price,
                                sd.QuantitySold,
                                sd.Subtotal
                           from Sales s
                           inner join SalesDetails sd on s.Id = sd.SalesId
                           inner join Item i on sd.ItemId = i.Id
                           order by s.SaleDate desc";

            List<SalesDetailsDTO> salesDetails = new List<SalesDetailsDTO>(); 
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                salesDetails.Add(new SalesDetailsDTO
                                {
                                    Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                    SaleDate = reader.GetDateTime(reader.GetOrdinal("SaleDate")),
                                    ItemName = reader.GetString(reader.GetOrdinal("ItemName")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                    QuantitySold = reader.GetInt32(reader.GetOrdinal("QuantitySold")),
                                    SubTotal = reader.GetDecimal(reader.GetOrdinal("SubTotal"))
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        return salesDetails;
                    }
                }
            }
            return salesDetails;
        }

        public IEnumerable<ReportDTO> GetAllReports()
        {
            string query = @"select 
                                cast(s.SaleDate as Date) as SaleDate,
                                count(distinct s.Id) as Transactions,
                                sum(sd.QuantitySold) as TotalQuantitySold,
                                sum(s.TotalAmount) as TotalAmount
                           from Sales s
                           join SalesDetails sd on s.Id = sd.SalesId
                           group by cast(s.SaleDate as Date)
                           order by SaleDate desc";

            List<ReportDTO> reports = new List<ReportDTO>();
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                reports.Add(new ReportDTO
                                {
                                    SaleDate = reader.GetDateTime(reader.GetOrdinal("SaleDate")),
                                    Transactions = reader.GetInt32(reader.GetOrdinal("Transactions")),
                                    TotalQuantitySold = reader.GetInt32(reader.GetOrdinal("TotalQuantitySold")),
                                    TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount"))
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        return reports;
                    }
                }
            }
            return reports;
        }

        public IEnumerable<ReportDTO> GetAllReportsByDates(DateTime start, DateTime end)
        {
            string query = @"select 
                                cast(s.SaleDate as Date) as SaleDate,
                                count(distinct s.Id) as Transactions,
                                sum(sd.QuantitySold) as TotalQuantitySold,
                                sum(s.TotalAmount) as TotalAmount
                           from Sales s
                           join SalesDetails sd on s.Id = sd.SalesId
                           where cast(s.SaleDate as Date) between 
                           @StartDate and @EndDate
                           group by cast(s.SaleDate as Date)   
                           order by SaleDate desc";

            List<ReportDTO> reports = new List<ReportDTO>();
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        cmd.Parameters.AddWithValue("@StartDate", start);
                        cmd.Parameters.AddWithValue("@EndDate", end);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                reports.Add(new ReportDTO
                                {
                                    SaleDate = reader.GetDateTime(reader.GetOrdinal("SaleDate")),
                                    Transactions = reader.GetInt32(reader.GetOrdinal("Transactions")),
                                    TotalQuantitySold = reader.GetInt32(reader.GetOrdinal("TotalQuantitySold")),
                                    TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount"))
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        return reports;
                    }
                }
            }
            return reports;
        }
    }
}
