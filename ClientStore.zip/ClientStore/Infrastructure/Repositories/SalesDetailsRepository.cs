﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Interfaces.Repository;
using Core.Model;
using Core.DTOs;
using Microsoft.Data.SqlClient;

namespace Infrastructure.Repositories
{
    public class SalesDetailsRepository : ISalesDetailsRepository
    {
        private readonly string _conStr;
        public SalesDetailsRepository(string conStr)
        {
            _conStr = conStr;
        }
        public bool Add(SalesDetails salesDetails)
        {
            string query = @"insert into SalesDetails 
                            (SalesId, ItemId, QuantitySold, SubTotal)  
                            values (@SalesId, @ItemId, @QuantitySold, @SubTotal)";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@SalesId", salesDetails.SalesId);
                        cmd.Parameters.AddWithValue("@ItemId", salesDetails.ItemId);
                        cmd.Parameters.AddWithValue("@QuantitySold", salesDetails.QuantitySold);
                        cmd.Parameters.AddWithValue("@SubTotal", salesDetails.SubTotal);
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public IEnumerable<SalesDetailsDTO> GetAll()
        {
            string query = @"select 
                                sd.Id,
                                s.SaleDate,
                                sd.ItemId,
                                sd.QuantitySold,
                                sd.Subtotal
                           from Sales s
                           inner join SalesDetails sd on s.Id = sd.SalesId
                           order by s.SaleDate desc";

            // with ItemName and Price
            string queryOG = @"select 
                                sd.Id,
                                s.SaleDate,
                                i.Name as ItemName,
                                i.Price,
                                sd.QuantitySold,
                                sd.Subtotal
                           from Sales s
                           inner join SalesDetails sd on s.Id = sd.SalesId
                           inner join Item i on sd.ItemId = i.Id
                           order by s.SaleDate desc";

            string queryBetter = @"SELECT 
                                    s.SaleDate,
	                                s.Id AS SaleId,
                                    s.TotalAmount,
                                    sd.ItemId,
                                    sd.QuantitySold,
                                    sd.SubTotal
                                FROM Sales s
                                INNER JOIN SalesDetails sd ON s.Id = sd.SalesId";

            List<SalesDetailsDTO> salesDetails = new List<SalesDetailsDTO>(); 
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(queryBetter, con))
                {
                    try
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                salesDetails.Add(new SalesDetailsDTO
                                {
                                    //Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                    SaleId = reader.GetInt32(reader.GetOrdinal("SaleId")),
                                    ItemId = reader.GetInt32(reader.GetOrdinal("ItemId")),
                                    SaleDate = reader.GetDateTime(reader.GetOrdinal("SaleDate")),
                                    //ItemName = reader.GetString(reader.GetOrdinal("ItemName")),
                                    //Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                    QuantitySold = reader.GetInt32(reader.GetOrdinal("QuantitySold")),
                                    SubTotal = reader.GetDecimal(reader.GetOrdinal("SubTotal")),
                                    TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount"))
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        return salesDetails;
                    }
                }
            }
            return salesDetails;
        }


        public IEnumerable<ReportDTO> GetAllReports()
        {
            string query = @"
                           SELECT 
                                CAST(s.SaleDate AS DATE) AS SaleDate,
                                COUNT(DISTINCT s.Id) AS Transactions,
                                SUM(DISTINCT s.TotalAmount) AS TotalAmount,
                                SUM(sd.QuantitySold) AS TotalQuantitySold
                            FROM Sales s
                            INNER JOIN SalesDetails sd ON s.Id = sd.SalesId
                            GROUP BY CAST(s.SaleDate AS DATE)
                            ORDER BY SaleDate DESC";

            List<ReportDTO> reports = new List<ReportDTO>();
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                reports.Add(new ReportDTO
                                {
                                    SaleDate = reader.GetDateTime(reader.GetOrdinal("SaleDate")),
                                    Transactions = reader.GetInt32(reader.GetOrdinal("Transactions")),
                                    TotalQuantitySold = reader.GetInt32(reader.GetOrdinal("TotalQuantitySold")),
                                    TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount"))
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        return reports;
                    }
                }
            }
            return reports;
        }

        public IEnumerable<ReportDTO> GetAllReportsByDates(DateTime start, DateTime end)
        {
            string query = @"SELECT 
                                CAST(s.SaleDate AS DATE) AS SaleDate,
                                COUNT(DISTINCT s.Id) AS Transactions,
                                SUM(DISTINCT s.TotalAmount) AS TotalAmount,
                                SUM(sd.QuantitySold) AS TotalQuantitySold
                            FROM Sales s
                            INNER JOIN SalesDetails sd ON s.Id = sd.SalesId
                            WHERE CAST(s.SaleDate AS DATE) BETWEEN @StartDate AND @EndDate
                            GROUP BY CAST(s.SaleDate AS DATE)
                            ORDER BY SaleDate DESC";

            List<ReportDTO> reports = new List<ReportDTO>();
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        cmd.Parameters.AddWithValue("@StartDate", start);
                        cmd.Parameters.AddWithValue("@EndDate", end);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                reports.Add(new ReportDTO
                                {
                                    SaleDate = reader.GetDateTime(reader.GetOrdinal("SaleDate")),
                                    Transactions = reader.GetInt32(reader.GetOrdinal("Transactions")),
                                    TotalQuantitySold = reader.GetInt32(reader.GetOrdinal("TotalQuantitySold")),
                                    TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount"))
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        return reports;
                    }
                }
            }
            return reports;
        }

    }
}
