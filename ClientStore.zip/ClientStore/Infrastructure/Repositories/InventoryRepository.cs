﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Interfaces.Repository;
using Core.Model;
using Core.DTOs;
using Microsoft.Data.SqlClient;

namespace Infrastructure.Repositories
{
    public class InventoryRepository : IInventoryRepository
    {
        private readonly string _conStr;
        public InventoryRepository(string conStr) {
            _conStr = conStr;
        }
        
        public bool AddQuantityByItemId(int itemId, int quantity)
        {
            string query = "insert into Inventory (ItemId, Quantity) values (@ItemId, @Quantity)";
            using (SqlConnection con = new SqlConnection(_conStr)) {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@ItemId", itemId);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        // delete by itemId
        public bool DeleteById(int id)
        {
            string query = "delete from Inventory where ItemId = @ItemId";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@ItemId", id);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
                catch (Exception)
                {
                    return false;
                }
            }
            
        }

        public IEnumerable<InventoryDTO> GetAll()
        {
            string query = @"select 
                                Inventory.Id, 
                                Inventory.ItemId,
                                Item.Name as ItemName, 
                                Item.Price,
                                Inventory.Quantity 
                            from Inventory 
                            inner join Item on Inventory.ItemId = Item.Id";
            List<InventoryDTO> inventories = new List<InventoryDTO>();
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                inventories.Add(new InventoryDTO
                                {
                                    Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                    ItemId = reader.GetInt32(reader.GetOrdinal("ItemId")),
                                    ItemName = reader.GetString(reader.GetOrdinal("ItemName")),
                                    Quantity = reader.GetInt32(reader.GetOrdinal("Quantity")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price"))
                                });
                            }   
                        }
                    }
                    catch (Exception ex)
                    {
                        // throw error
                        Console.WriteLine(ex.Message);
                        return inventories;
                    }
                }

                return inventories;
            }
        }

        public bool UpdateQuantityById(int id, int quantity)
        {
            string query = "update Inventory set Quantity = @Quantity where ItemId = @ItemId";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);
                    cmd.Parameters.AddWithValue("@ItemId", id);
                    con.Open();
                    int rowsAffeted = cmd.ExecuteNonQuery();
                    return rowsAffeted > 0;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }
    }
}
