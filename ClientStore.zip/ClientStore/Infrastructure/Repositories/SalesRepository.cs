﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Interfaces.Repository;
using Core.Model;
using Microsoft.Data.SqlClient;

namespace Infrastructure.Repositories
{
    public class SalesRepository : ISalesRepository
    {
        private readonly string _conStr; 
        public SalesRepository(string conStr) {
            _conStr = conStr;
        } 
        public int AddSales(decimal totalAmount)
        {
            string query = @"insert into Sales (TotalAmount) values (@TotalAmount)
                             select cast(scope_identity() as int)";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
                        con.Open();
                        int insertedId = (int)cmd.ExecuteScalar();
                        return insertedId;
                    }
                }
                catch (Exception)
                {
                    return -1;
                }
            }
        }

        public bool UpdateTotalAmountById(int id, decimal totalAmount)
        {
            string query = "update Sales set TotalAmount = @TotalAmount where Id = @Id";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
                        cmd.Parameters.AddWithValue("@Id", id);
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }
    }
}
