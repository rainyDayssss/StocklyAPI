﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Model;
namespace GroceryCalcApp.Models
{
    public class GroceryDiscountCalculator
    {
        private UserGroceryCart userGroceryCart;
        private Decimal totalPriceBeforeDiscount;
        private Decimal totalPriceAfterDiscount;

        // Base 10 dicount amount not the percentage
        private Decimal discountAmount;

        // Add the user grocery cart to allow calculations
        public GroceryDiscountCalculator(UserGroceryCart userGroceryCart) {
            this.userGroceryCart = userGroceryCart;
            totalPriceBeforeDiscount = 0;
            totalPriceAfterDiscount = 0;
            discountAmount = 0;
        }

        public void CalcTotalPriceBeforeDiscount() {
            foreach (Item item in userGroceryCart.GetAllItems())
            {
                totalPriceBeforeDiscount += item.Price * item.PurchasedQuantity;
            }
        }

        // Implemented a static class to group the dicounts percentage constant together
        public Decimal CalcDiscount() {

            if (totalPriceBeforeDiscount > 500m) {
                discountAmount = totalPriceBeforeDiscount * Discount.TWENTY_PERCENT;
                return Discount.TWENTY_PERCENT; // Return the Decimal of the discount for display purposes
            }
            else if (totalPriceBeforeDiscount > 200m) {
                discountAmount = totalPriceBeforeDiscount * Discount.FIFTEEN_PERCENT;
                return Discount.FIFTEEN_PERCENT;
            }
            else if (totalPriceBeforeDiscount > 100m) {
                discountAmount = totalPriceBeforeDiscount * Discount.TEN_PERCENT;
                return Discount.TEN_PERCENT;
            }
            else {
                discountAmount = 0m;
                return 0m;
            }
        }

        public void CalcTotalPriceAfterDiscount() {
            totalPriceAfterDiscount = totalPriceBeforeDiscount - discountAmount;
        }

        // Created getters to allow modifcation within the class while also allowing public read methods to these values
        // This cannot be implemented with just varname { get; }
        public Decimal GetTotalPriceBeforeDiscount() { return totalPriceBeforeDiscount; }
        public Decimal GetTotalPriceAfterDiscount() { return totalPriceAfterDiscount; }
        public Decimal GetDiscountAmount() { return discountAmount; }
        
    }
}
