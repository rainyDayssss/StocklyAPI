﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroceryCalcApp.Models
{
    public class StockItemsStorage
    {
        // For O(1) search and add
        private Dictionary<int, Item> stockItems;
        public StockItemsStorage()
        {
            stockItems = new Dictionary<int, Item>();
        }

        // add the Id as the key of the item object
        public void AddItem(Item item)
        {
            stockItems.Add(item.Id, item);
        }

        // key == id
        public bool ContainsKey(int id)
        {
            return stockItems.ContainsKey(id);
        }

        // return the item of the specified key / id
        public Item GetItemById(int id)
        {
            return stockItems[id];
        }

        // return the list version of the stock items to prevent access to the original stock items 
        public List<Item> GetAllItems()
        {
            return stockItems.Values.ToList();
        }
    }
}
