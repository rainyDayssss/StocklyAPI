﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GroceryCalcApp.Exceptions;

namespace GroceryCalcApp.Models
{
    public class UserGroceryCart
    {
        private StockItemsStorage stockItemsStorage;
        private Dictionary<int, Item> cartItems;
        public UserGroceryCart(StockItemsStorage stockItemsStorage)
        {
            this.stockItemsStorage = stockItemsStorage;
            cartItems = new Dictionary<int, Item>();
        }


        // checks first if the item exist in the storage, if true then...
        public void AddItemById(int id)
        {
            if (stockItemsStorage.ContainsKey(id))
            {
                cartItems.Add(id, stockItemsStorage.GetItemById(id)); // then add the modified Item object to the cartItems
                return;
            }

            // throws an exception if the item was not found
            throw new ItemNotFoundException($"Item with id {id} was not found!");
        }

        // set the new purchase quantity that the user wants to buy
        public void AddQuantityById(int id, int purchasedQuantity)
        {
            if (cartItems.ContainsKey(id)) {
                cartItems[id].PurchasedQuantity += purchasedQuantity;
            }
        }

        // mainly for the calculator to calculate the total prices
        public List<Item> GetAllItems() {
            return cartItems.Values.ToList();
        }

        public bool IsEmpty() {
            return cartItems.Count == 0;
        }

        public bool ContainsKey(int id) {
            return cartItems.ContainsKey(id);
        }

    }
}
