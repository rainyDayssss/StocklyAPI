﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroceryCalcApp.Models
{
    public class Item
    {
        public int Id { get; }
        public string Name { get; set; }
        public decimal Price { get; }
        public int PurchasedQuantity { get; set; }

        public Item(int id, string name, decimal price)
        {
            Id = id;
            Name = name;
            Price = price;
            PurchasedQuantity = 0; // set to 0 for the stock items storage // Stock Quantity is to be implemented 
        }
        
    }
}
