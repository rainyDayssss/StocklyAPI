﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.DTOs;
using Core.Model;

namespace Core.Interfaces.Service
{
    public interface IInventoryService
    {
        IEnumerable<InventoryDTO> GetAll();
        bool AddQuantityByItemId(int itemId, int quantity);
        bool DeleteById(int id);
        bool UpdateQuantityById(int id, int quantity);
    }
}
