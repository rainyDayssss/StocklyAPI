﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Interfaces.Service
{
    public interface ISalesService
    {
        public int AddSales(decimal totalAmount);
        public bool UpdateTotalAmountById(int id, decimal totalAmount);
    }
}
