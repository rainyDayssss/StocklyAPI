﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Model
{
    public class Sales
    {
        public int Id { set; get; }
        public DateTime SaleDate { set; get; }
        public decimal TotalAmount {set; get;}

        public Sales() { }
        public Sales(int id, DateTime saleDate, decimal totalAmount) {
            Id = id;
            SaleDate = saleDate;
            TotalAmount = totalAmount;
        }
    }
}
