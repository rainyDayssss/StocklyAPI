﻿select * from Item

create table Inventory (
	Id int primary key identity(1,1),
	ItemId int not null,
	Quantity int not null check (Quantity >= 0), -- Prevent negative quantities
	
	constraint Fk_Inventory_Item_ID foreign key (ItemID) references Item(ID) on delete cascade -- automatically delete item a if item a is deleted from Item table
);

select * from Inventory