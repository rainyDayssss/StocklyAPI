﻿using Core.Interfaces.Service;

namespace Infrastructure.Utilities
{
    public class AppServices
    {
        public IItemService ItemService { get; }
        public IInventoryService InventoryService { get; }
        public ISalesService SalesService { get; }
        public ISalesDetailsService SalesDetailsService { get; }

        public AppServices(
            IItemService itemService,
            IInventoryService inventoryService,
            ISalesService salesService,
            ISalesDetailsService salesDetailsService)
        {
            ItemService = itemService;
            InventoryService = inventoryService;
            SalesService = salesService;
            SalesDetailsService = salesDetailsService;
        }
    }
}
