﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Infrastructure.Utilities;

namespace InventoryManagement
{
    public partial class InventoryPage : Form
    {
        private readonly AppServices _appServices;
        public InventoryPage(AppServices appServices)
        {
            InitializeComponent();
            deletePanel1.Location = new Point(309, 231);
            _appServices = appServices;
            foreach (var inv in _appServices.InventoryService.GetAll())
            {
                grid.Rows.Add(inv.ItemId, inv.ItemName, inv.Quantity);
            }
        }


        private void InventoryPage_Load(object sender, EventArgs e)
        {

        }

        private void cuiLabel4_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            DeleteButton.Enabled = false;
            grid.Enabled = false;
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            deletePanel1.Visible = true;
            AddButton.Enabled = false;
            grid.Enabled = false;
        }

        // delete item by item id btn
        private void deleteItem_Click(object sender, EventArgs e)
        {
            deletePanel1.Visible = false;
            AddButton.Enabled = true;
            grid.Enabled = true;

            _appServices.InventoryService.DeleteById(int.Parse(cuiTextBox4.Content));
            refreshItems();
            cuiTextBox4.Content = "";
        }

        // add inventory
        private void addItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            DeleteButton.Enabled = true;
            grid.Enabled = true;

            // add product name
            _appServices.InventoryService.AddQuantityByItemId(int.Parse(cuiTextBox1.Content), int.Parse(cuiTextBox2.Content));

            refreshItems();

            // clear texts
            cuiTextBox1.Content = "";
            cuiTextBox2.Content = "";
        }

        private void refreshItems()
        {
            grid.Rows.Clear();
            foreach (var inv in _appServices.InventoryService.GetAll())
            {
                grid.Rows.Add(inv.ItemId, inv.ItemName, inv.Quantity);
            }
        }
        private void cancel_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            DeleteButton.Enabled = true;
            grid.Enabled = true;
        }

        // might be the item delete
        private void grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0 && grid.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                // Step 1: Get the ID from the clicked row
                int id = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Column1"].Value);

                // Step 2: Delete from the database
                bool success = _appServices.InventoryService.DeleteById(id);

                // Step 3: Remove from grid if successful
                if (success)
                {
                    grid.Rows.RemoveAt(e.RowIndex);
                }
                else
                {
                    MessageBox.Show("Failed to delete from database.");
                }
            }
        }

        private void deletePanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cuiTextBox2_ContentChanged(object sender, EventArgs e)
        {

        }
    }
}
