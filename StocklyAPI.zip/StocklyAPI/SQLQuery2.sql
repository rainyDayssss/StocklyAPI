﻿select * from Inventory

select * from Item

CREATE TABLE Sales (
	ID INT PRIMARY KEY IDENTITY(1,1),
	SaleDate DATETIME DEFAULT GETDATE(),
	TotalAmount DECIMAL(10,2) DEFAULT 0 CHECK (TotalAmount >= 0) -- Sum of SaleDetails
);



select * from Sales

CREATE TABLE SalesDetails (
    ID INT PRIMARY KEY IDENTITY(1,1),
    
    SalesID INT NOT NULL,
    ItemID INT NOT NULL,
    QuantitySold INT NOT NULL CHECK (QuantitySold > 0),
    SubTotal DECIMAL(10,2) NOT NULL, -- Auto-calculated, stored value
    
    CONSTRAINT FK_SalesDetails_Sales FOREIGN KEY (SalesID) REFERENCES Sales(ID),
    CONSTRAINT FK_SalesDetails_Item FOREIGN KEY (ItemID) REFERENCES Item(ID)
);

select * from SalesDetails

select 
                                s.SaleDate,
                                i.Name as ItemName,
                                i.Price,
                                sd.QuantitySold,
                                sd.Subtotal
                           from Sales s
                           inner join SalesDetails sd on s.Id = sd.SalesId
                           inner join Item i on sd.ItemId = i.Id


