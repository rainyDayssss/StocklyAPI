﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.DTOs;
using Core.Interfaces.Repository;
using Core.Interfaces.Service;
using Core.Model;

namespace Infrastructure.Services
{
    public class SalesDetailsService : ISalesDetailsService
    {
        private readonly ISalesDetailsRepository _salesDetailsRepo;
        public SalesDetailsService(ISalesDetailsRepository salesDetailsRepo) {
            _salesDetailsRepo = salesDetailsRepo;
        }

        public bool Add(SalesDetails salesDetails)
        {
            return _salesDetailsRepo.Add(salesDetails);
        }

        public IEnumerable<SalesDetailsDTO> GetAll()
        {
            return _salesDetailsRepo.GetAll();
        }
    }
}
