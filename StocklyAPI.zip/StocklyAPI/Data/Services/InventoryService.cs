﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.DTOs;
using Core.Interfaces.Repository;
using Core.Interfaces.Service;

namespace Infrastructure.Services
{
    public class InventoryService : IInventoryService
    {
        private readonly IInventoryRepository _invRepo;
        public InventoryService(IInventoryRepository invRepo)
        {
            _invRepo = invRepo;
        }

        public bool AddQuantityByItemId(int itemId, int quantity)
        {
            return _invRepo.AddQuantityByItemId(itemId, quantity);
        }

        public bool DeleteById(int id)
        {
            return _invRepo.DeleteById(id);
        }

        public IEnumerable<SalesDetailsRepository> GetAll()
        {
            return _invRepo.GetAll();
        }

        public bool UpdateQuantityById(int id, int quantity)
        {
            return _invRepo.UpdateQuantityById(id, quantity);
        }
    }
}
