﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Interfaces.Repository;
using Core.Model;
using Core.DTOs;
using Microsoft.Data.SqlClient;

namespace Infrastructure.Repositories
{
    public class SalesDetailsRepository : ISalesDetailsRepository
    {
        private readonly string _conStr;
        public SalesDetailsRepository(string conStr)
        {
            _conStr = conStr;
        }
        public bool Add(SalesDetails salesDetails)
        {
            string query = @"insert into SalesDetails 
                            (SalesId, ItemId, QuantitySold, SubTotal)  
                            values (@SalesId, @ItemId, @QuantitySold, @SubTotal)";
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@SalesId", salesDetails.SalesId);
                        cmd.Parameters.AddWithValue("@ItemId", salesDetails.ItemId);
                        cmd.Parameters.AddWithValue("@QuantitySold", salesDetails.QuantitySold);
                        cmd.Parameters.AddWithValue("@SubTotal", salesDetails.SubTotal);
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public IEnumerable<SalesDetailsDTO> GetAll()
        {
            string query = @"select 
                                sd.Id,
                                s.SaleDate,
                                i.Name as ItemName,
                                i.Price,
                                sd.QuantitySold,
                                sd.Subtotal
                           from Sales s
                           inner join SalesDetails sd on s.Id = sd.SalesId
                           inner join Item i on sd.ItemId = i.Id";
            List<SalesDetailsDTO> salesDetails = new List<SalesDetailsDTO>(); 
            using (SqlConnection con = new SqlConnection(_conStr))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                salesDetails.Add(new SalesDetailsDTO
                                {
                                    Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                    SaleDate = reader.GetDateTime(reader.GetOrdinal("SaleDate")),
                                    ItemName = reader.GetString(reader.GetOrdinal("ItemName")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                    QuantitySold = reader.GetInt32(reader.GetOrdinal("QuantitySold")),
                                    SubTotal = reader.GetDecimal(reader.GetOrdinal("SubTotal"))
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        return salesDetails;
                    }
                }
            }
            return salesDetails;
        }
    }
}
