﻿// See https://aka.ms/new-console-template for more information
using Core.Interfaces.Repository;
using Core.Model;
using Infrastructure.Repositories;
using Core.DTOs;

string conStr = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Test1;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

ItemRepository itemRepo = new ItemRepository(conStr);
IInventoryRepository invRepo = new InventoryRepository(conStr);
ISalesDetailsRepository sdr = new Infrastructure.Repositories.SalesDetailsRepository(conStr);
ISalesRepository sr = new SalesRepository(conStr);

//bool _ = itemRepo.Add(new Item
//{
//    Name = "Apple",
//    Price = 10m
//});


//Console.WriteLine("1");

foreach (SalesDetailsDTO sales in sdr.GetAll().ToList()) {
    Console.WriteLine(sales.SaleDate.Date.ToString("MM-dd-yy") + " " + sales.Id + " " + sales.ItemName + " " + sales.Price + " " + sales.QuantitySold + " " + sales.SubTotal);
}

//Console.WriteLine("2");

//Console.WriteLine(invRepo.AddQuantityByItemId(2, 20));

// creating a sale

//Console.WriteLine(sdr.Add(new SalesDetails
//{
//    ItemId = 2,
//    SalesId = sr.AddSales(0),
//    QuantitySold = 100,
//    SubTotal = 500 // ($5 * 100 sold)
//}));

//Console.WriteLine("3")



foreach (SalesDetailsDTO sales in sdr.GetAll().ToList())
{
    Console.WriteLine(sales.Id + " " + sales.ItemName + " " + sales.Price + " " + sales.QuantitySold + " " + sales.SubTotal);
}


//Console.WriteLine("4");