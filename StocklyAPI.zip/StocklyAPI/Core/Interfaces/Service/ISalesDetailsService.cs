﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.DTOs;
using Core.Model;

namespace Core.Interfaces.Service
{
    public interface ISalesDetailsService
    {
        public IEnumerable<SalesDetailsDTO> GetAll();
        public bool Add(SalesDetails salesDetails);
    }
}
