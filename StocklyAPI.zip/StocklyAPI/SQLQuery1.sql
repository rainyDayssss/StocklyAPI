﻿create table Item (
	Id int primary key identity(1,1),
	Name varchar(255) not null,
	Price decimal(10,2) not null check (Price >= 0)
)

create table Inventory (
	ID int primary key identity(1,1),
	ItemId int not null,
	Quantity int not null check (Quantity >= 0), -- Prevent negative quantities
	
	constraint Fk_Inventory_Item_ID foreign key (ItemID) references Item(ID) on delete cascade -- automatically delete item a if item a is deleted from Item table
);

